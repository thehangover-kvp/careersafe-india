import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'careersafe-india-secret-dev-key-2026')
    DATABASE_PATH = os.path.join(BASE_DIR, 'careersafe.db')
    APP_NAME = "CareerSafe India"
    TAGLINE = "Fake Job & Internship Detection System for Indian Students"
