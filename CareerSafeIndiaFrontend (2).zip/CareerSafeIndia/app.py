"""
CareerSafe India - Flask Application
Fake Job and Internship Detection System for Indian Students and Job Seekers.
"""
import os
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from config import Config
import database as db
import checker

app = Flask(__name__)
app.config.from_object(Config)

# Ensure database exists and is initialized
with app.app_context():
    db.init_db(app.config["DATABASE_PATH"])


@app.context_processor
def inject_global_data():
    """Injects unread notification count and global app constants into all Jinja templates."""
    try:
        dash_data = db.get_user_dashboard_data(app.config["DATABASE_PATH"])
        unread_count = dash_data.get("unread_notifications_count", 0)
    except Exception:
        unread_count = 0
    return {
        "app_name": app.config.get("APP_NAME", "CareerSafe India"),
        "app_tagline": app.config.get("TAGLINE", "Fake Job & Internship Detection System"),
        "unread_notifications_count": unread_count,
        "is_demo_mode": True
    }


# -------------------------------------------------------------------
# Core Routes
# -------------------------------------------------------------------

@app.route("/")
def index():
    """Home Page with hero, key statistics, quick scan launcher, and recent scam alerts."""
    companies = db.get_companies(db_path=app.config["DATABASE_PATH"])[:4]
    recent_jobs = db.get_jobs(db_path=app.config["DATABASE_PATH"])[:3]
    recent_internships = db.get_internships(db_path=app.config["DATABASE_PATH"])[:3]
    dash_data = db.get_user_dashboard_data(db_path=app.config["DATABASE_PATH"])
    recent_alerts = [n for n in dash_data.get("notifications", []) if n["severity"] in ["danger", "warning"]][:3]
    presets = checker.get_demo_presets()

    return render_template(
        "index.html",
        companies=companies,
        recent_jobs=recent_jobs,
        recent_internships=recent_internships,
        recent_alerts=recent_alerts,
        presets=presets
    )


@app.route("/companies")
def companies():
    """Company Directory with search, industry, and verification status filter."""
    query = request.args.get("q", "").strip()
    industry = request.args.get("industry", "").strip()
    status = request.args.get("status", "").strip()
    companies_list = db.get_companies(query=query, industry=industry, status=status, db_path=app.config["DATABASE_PATH"])
    return render_template(
        "companies.html",
        companies=companies_list,
        query=query,
        selected_industry=industry,
        selected_status=status
    )


@app.route("/companies/<slug>")
def company_detail(slug):
    """Company Detail profile with verified portals, official email domains, and fraud alerts."""
    company = db.get_company_by_slug(slug, db_path=app.config["DATABASE_PATH"])
    if not company:
        flash("Company profile not found.", "warning")
        return redirect(url_for("companies"))
    return render_template("company_detail.html", company=company)


@app.route("/jobs")
def jobs():
    """Job Finder with filters (Domain, Location, Work Mode, Experience, Status)."""
    query = request.args.get("q", "").strip()
    domain = request.args.get("domain", "").strip()
    location = request.args.get("location", "").strip()
    work_mode = request.args.get("mode", "").strip()
    experience = request.args.get("exp", "").strip()
    status = request.args.get("status", "").strip()

    jobs_list = db.get_jobs(
        query=query,
        domain=domain,
        location=location,
        work_mode=work_mode,
        experience=experience,
        status=status,
        db_path=app.config["DATABASE_PATH"]
    )
    return render_template(
        "jobs.html",
        jobs=jobs_list,
        query=query,
        selected_domain=domain,
        selected_location=location,
        selected_mode=work_mode,
        selected_exp=experience,
        selected_status=status
    )


@app.route("/jobs/<int:job_id>")
def job_detail(job_id):
    """Job Detail view with source link, last checked date, and full verification audit explanation."""
    job = db.get_job_by_id(job_id, db_path=app.config["DATABASE_PATH"])
    if not job:
        flash("Job listing not found.", "warning")
        return redirect(url_for("jobs"))
    return render_template("job_detail.html", job=job)


@app.route("/internships")
def internships():
    """Internship Finder with filters (Domain, Location, Work Mode, Stipend, Duration, Status)."""
    query = request.args.get("q", "").strip()
    domain = request.args.get("domain", "").strip()
    location = request.args.get("location", "").strip()
    work_mode = request.args.get("mode", "").strip()
    duration = request.args.get("duration", "").strip()
    stipend_filter = request.args.get("stipend", "").strip()
    status = request.args.get("status", "").strip()

    internships_list = db.get_internships(
        query=query,
        domain=domain,
        location=location,
        work_mode=work_mode,
        duration=duration,
        stipend_filter=stipend_filter,
        status=status,
        db_path=app.config["DATABASE_PATH"]
    )
    return render_template(
        "internships.html",
        internships=internships_list,
        query=query,
        selected_domain=domain,
        selected_location=location,
        selected_mode=work_mode,
        selected_duration=duration,
        selected_stipend=stipend_filter,
        selected_status=status
    )


@app.route("/internships/<int:internship_id>")
def internship_detail(internship_id):
    """Internship Detail view with source link, last checked date, and full verification audit explanation."""
    internship = db.get_internship_by_id(internship_id, db_path=app.config["DATABASE_PATH"])
    if not internship:
        flash("Internship listing not found.", "warning")
        return redirect(url_for("internships"))
    return render_template("internship_detail.html", internship=internship)


@app.route("/checker", methods=["GET", "POST"])
def offer_checker():
    """Fake Job & Internship Offer Checker Page."""
    presets = checker.get_demo_presets()
    result = None
    form_data = {}

    if request.method == "POST":
        form_data = {
            "company_name": request.form.get("company_name", ""),
            "job_title": request.form.get("job_title", ""),
            "recruiter_email": request.form.get("recruiter_email", ""),
            "contact_mode": request.form.get("contact_mode", "Official Job Portal"),
            "interview_process": request.form.get("interview_process", "Multi-round Interview"),
            "salary_offered": request.form.get("salary_offered", ""),
            "fee_demanded_type": request.form.get("fee_demanded_type", "None"),
            "fee_amount": request.form.get("fee_amount", "0"),
            "offer_text": request.form.get("offer_text", "")
        }

        # Analyze offer
        result = checker.analyze_offer(form_data)

        # Record scan to history in database
        try:
            db.record_scan_result({
                "company_name": form_data["company_name"],
                "job_title": form_data["job_title"],
                "recruiter_email": form_data["recruiter_email"],
                "salary_offered": form_data["salary_offered"],
                "fee_demanded_type": form_data["fee_demanded_type"],
                "fee_amount": float(form_data.get("fee_amount") or 0),
                "risk_score": result["score"],
                "risk_level": result["risk_level"],
                "verdict_title": result["verdict_title"],
                "verdict_summary": result["verdict_summary"]
            }, db_path=app.config["DATABASE_PATH"])
        except Exception as e:
            app.logger.error(f"Error saving scan result: {e}")

    return render_template(
        "checker.html",
        presets=presets,
        result=result,
        form_data=form_data
    )


@app.route("/dashboard")
def dashboard():
    """User Dashboard showing saved jobs, saved internships, scan history, and notifications."""
    dash_data = db.get_user_dashboard_data(db_path=app.config["DATABASE_PATH"])
    return render_template("dashboard.html", data=dash_data)


@app.route("/report-scam", methods=["GET", "POST"])
def report_scam():
    """Community Scam Report form."""
    if request.method == "POST":
        report_data = {
            "scammer_name": request.form.get("scammer_name", ""),
            "company_impersonated": request.form.get("company_impersonated", ""),
            "contact_method": request.form.get("contact_method", ""),
            "email_or_phone": request.form.get("email_or_phone", ""),
            "amount_demanded": request.form.get("amount_demanded", ""),
            "details": request.form.get("details", "")
        }
        db.record_scam_report(report_data, db_path=app.config["DATABASE_PATH"])
        flash("Thank you! Your fraud report has been submitted to help safeguard other students.", "success")
        return redirect(url_for("dashboard"))
    return render_template("report_scam.html")


@app.route("/about-safety")
def about_safety():
    """Student Safety Guide & Red Flags Reference."""
    return render_template("about_safety.html")


# -------------------------------------------------------------------
# JSON API Endpoints for Interactive Client UI
# -------------------------------------------------------------------

@app.route("/api/check-offer", methods=["POST"])
def api_check_offer():
    """Instant JSON analysis endpoint for AJAX offer checks."""
    data = request.get_json() or {}
    result = checker.analyze_offer(data)

    try:
        db.record_scan_result({
            "company_name": data.get("company_name", "Unknown"),
            "job_title": data.get("job_title", "Unknown"),
            "recruiter_email": data.get("recruiter_email", ""),
            "salary_offered": data.get("salary_offered", ""),
            "fee_demanded_type": data.get("fee_demanded_type", "None"),
            "fee_amount": float(data.get("fee_amount") or 0),
            "risk_score": result["score"],
            "risk_level": result["risk_level"],
            "verdict_title": result["verdict_title"],
            "verdict_summary": result["verdict_summary"]
        }, db_path=app.config["DATABASE_PATH"])
    except Exception as e:
        app.logger.error(f"Error saving scan result via API: {e}")

    return jsonify(result)


@app.route("/api/toggle-save", methods=["POST"])
def api_toggle_save():
    """Bookmark or unbookmark a job or internship."""
    data = request.get_json() or {}
    item_type = data.get("item_type")
    item_id = data.get("item_id")

    if not item_type or not item_id:
        return jsonify({"success": False, "error": "Missing item_type or item_id"}), 400

    try:
        is_saved = db.toggle_save_item(item_type, int(item_id), db_path=app.config["DATABASE_PATH"])
        return jsonify({"success": True, "is_saved": is_saved})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/mark-notification-read", methods=["POST"])
def api_mark_notification_read():
    """Marks a single notification as read."""
    data = request.get_json() or {}
    notif_id = data.get("id")
    if not notif_id:
        return jsonify({"success": False, "error": "Missing notification id"}), 400

    db.mark_notification_as_read(int(notif_id), db_path=app.config["DATABASE_PATH"])
    return jsonify({"success": True})


@app.route("/api/mark-all-read", methods=["POST"])
def api_mark_all_read():
    """Marks all notifications as read."""
    db.mark_all_notifications_as_read(db_path=app.config["DATABASE_PATH"])
    return jsonify({"success": True})


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
