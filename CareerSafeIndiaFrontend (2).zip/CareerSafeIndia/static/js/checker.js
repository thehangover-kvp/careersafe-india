/**
 * CareerSafe India - Offer Checker Interactive JavaScript
 * Manages demo preset loading, instant risk evaluation, and dynamic results visualization.
 */

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("offerCheckerForm");
  const resultContainer = document.getElementById("checkerResultContainer");
  const companyInput = document.getElementById("company_name");
  const titleInput = document.getElementById("job_title");
  const emailInput = document.getElementById("recruiter_email");
  const contactInput = document.getElementById("contact_mode");
  const interviewInput = document.getElementById("interview_process");
  const salaryInput = document.getElementById("salary_offered");
  const feeTypeInput = document.getElementById("fee_demanded_type");
  const feeAmountInput = document.getElementById("fee_amount");
  const offerTextInput = document.getElementById("offer_text");

  // Handle Preset Buttons Click
  document.querySelectorAll(".btn-preset").forEach((btn) => {
    btn.addEventListener("click", () => {
      const presetData = JSON.parse(btn.dataset.preset);
      if (!presetData) return;

      companyInput.value = presetData.company_name || "";
      titleInput.value = presetData.job_title || "";
      emailInput.value = presetData.recruiter_email || "";
      if (contactInput) contactInput.value = presetData.contact_mode || "Official Job Portal";
      if (interviewInput) interviewInput.value = presetData.interview_process || "Multi-round Interview";
      salaryInput.value = presetData.salary_offered || "";
      feeTypeInput.value = presetData.fee_demanded_type || "None";
      feeAmountInput.value = presetData.fee_amount || 0;
      offerTextInput.value = presetData.offer_text || "";

      // Trigger instant check
      runOfferAnalysis();
    });
  });

  // Handle Form Submit via AJAX for responsive experience
  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      runOfferAnalysis();
    });
  }

  async function runOfferAnalysis() {
    const payload = {
      company_name: companyInput.value.trim(),
      job_title: titleInput.value.trim(),
      recruiter_email: emailInput.value.trim(),
      contact_mode: contactInput ? contactInput.value : "Official Job Portal",
      interview_process: interviewInput ? interviewInput.value : "Multi-round Interview",
      salary_offered: salaryInput.value.trim(),
      fee_demanded_type: feeTypeInput.value,
      fee_amount: feeAmountInput.value || 0,
      offer_text: offerTextInput.value.trim()
    };

    if (!payload.company_name && !payload.offer_text) {
      alert("Please enter at least the company name or paste the offer text to screen.");
      return;
    }

    // Show loading state
    const submitBtn = document.getElementById("submitCheckBtn");
    const originalBtnText = submitBtn ? submitBtn.innerHTML : "Screen Offer";
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = "🔍 Scanning against Indian Scam Signatures...";
    }

    try {
      const response = await fetch("/api/check-offer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const result = await response.json();
      renderScanResult(result);
      
      // Smooth scroll to result on mobile
      if (resultContainer && window.innerWidth < 992) {
        resultContainer.scrollIntoView({ behavior: "smooth" });
      }
    } catch (err) {
      console.error("Error analyzing offer:", err);
      alert("Could not complete scan. Please try again.");
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
      }
    }
  }

  function renderScanResult(res) {
    if (!resultContainer) return;

    let colorClass = "danger";
    let meterFillClass = "fill-danger";
    if (res.risk_level === "LOW") {
      colorClass = "success";
      meterFillClass = "fill-success";
    } else if (res.risk_level === "MODERATE") {
      colorClass = "warning-medium";
      meterFillClass = "fill-warning-medium";
    } else if (res.risk_level === "HIGH") {
      colorClass = "warning-high";
      meterFillClass = "fill-warning-high";
    }

    let redFlagsHtml = "";
    if (res.red_flags && res.red_flags.length > 0) {
      redFlagsHtml = `
        <h4 style="font-size:0.95rem; font-weight:700; color:var(--danger); margin-top:1.25rem;">
          ⚠️ Red Flags Detected (${res.red_flags.length})
        </h4>
        <div class="flags-list">
          ${res.red_flags.map(f => `
            <div class="flag-item red">
              <div class="flag-item-title">❌ ${f.title}</div>
              <div>${f.description}</div>
            </div>
          `).join("")}
        </div>
      `;
    }

    let greenFlagsHtml = "";
    if (res.green_flags && res.green_flags.length > 0) {
      greenFlagsHtml = `
        <h4 style="font-size:0.95rem; font-weight:700; color:var(--success); margin-top:1.25rem;">
          ✅ Positive / Genuine Indicators (${res.green_flags.length})
        </h4>
        <div class="flags-list">
          ${res.green_flags.map(f => `
            <div class="flag-item green">
              <div class="flag-item-title">✓ ${f.title}</div>
              <div>${f.description}</div>
            </div>
          `).join("")}
        </div>
      `;
    }

    let recommendationsHtml = "";
    if (res.recommendations && res.recommendations.length > 0) {
      recommendationsHtml = `
        <h4 style="font-size:0.95rem; font-weight:700; color:var(--text-main); margin-top:1.25rem;">
          🛡️ Recommended Student Action Checklist
        </h4>
        <ul style="margin-left: 1.25rem; font-size: 0.85rem; color: var(--text-muted); margin-top: 0.5rem; display:flex; flex-direction:column; gap:0.35rem;">
          ${res.recommendations.map(r => `<li>${r}</li>`).join("")}
        </ul>
      `;
    }

    resultContainer.innerHTML = `
      <div class="result-card ${colorClass}">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span class="badge badge-${colorClass === 'success' ? 'verified' : (colorClass === 'danger' ? 'danger' : 'warning')}">
            ${res.risk_level} RISK
          </span>
          <span style="font-size:0.75rem; color:var(--text-light);">Screening Assessment</span>
        </div>

        <div class="risk-meter ${colorClass}">
          <div class="risk-score-display">${res.score}%</div>
          <div class="risk-label">${res.verdict_title}</div>
          <div class="meter-bar-container">
            <div class="meter-bar-fill ${meterFillClass}" style="width: ${res.score}%;"></div>
          </div>
        </div>

        <p style="font-size:0.9rem; color:var(--text-main); line-height:1.5; font-weight:500;">
          ${res.verdict_summary}
        </p>

        ${redFlagsHtml}
        ${greenFlagsHtml}
        ${recommendationsHtml}

        <div class="disclaimer-box">
          <strong>⚠️ Educational Screening Notice</strong>
          ${res.disclaimer}
        </div>
      </div>
    `;
  }
});
