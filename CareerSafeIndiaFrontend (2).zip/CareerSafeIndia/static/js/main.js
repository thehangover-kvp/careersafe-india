/**
 * CareerSafe India - Global JavaScript
 * Handles mobile navigation, bookmarking, notifications, and UI toasts.
 */

document.addEventListener("DOMContentLoaded", () => {
  // 1. Mobile Navigation Toggle
  const navToggle = document.getElementById("mobileNavToggle");
  const navLinks = document.getElementById("navLinks");
  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      navLinks.classList.toggle("show");
    });
  }

  // 2. Global Save / Bookmark Button handler
  document.querySelectorAll(".btn-save").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();

      const itemType = btn.dataset.itemType;
      const itemId = btn.dataset.itemId;

      if (!itemType || !itemId) return;

      try {
        const response = await fetch("/api/toggle-save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ item_type: itemType, item_id: itemId })
        });

        const data = await response.json();
        if (data.success) {
          if (data.is_saved) {
            btn.classList.add("saved");
            btn.innerHTML = `❤️ Saved`;
            showToast(`${itemType === 'job' ? 'Job' : 'Internship'} saved to your dashboard!`, "success");
          } else {
            btn.classList.remove("saved");
            btn.innerHTML = `🤍 Save`;
            showToast(`Item removed from your saved list.`, "info");
            
            // If on dashboard, remove item card dynamically
            const card = btn.closest(".saved-item-container");
            if (card) {
              card.style.opacity = "0";
              setTimeout(() => card.remove(), 250);
            }
          }
        }
      } catch (err) {
        console.error("Error toggling bookmark:", err);
        showToast("Could not update bookmark. Please try again.", "warning");
      }
    });
  });

  // 3. Dashboard Tab Switching
  const tabButtons = document.querySelectorAll(".dash-tab-btn");
  const tabContents = document.querySelectorAll(".dash-tab-content");

  tabButtons.forEach((tabBtn) => {
    tabBtn.addEventListener("click", () => {
      const targetId = tabBtn.dataset.tab;

      tabButtons.forEach((b) => b.classList.remove("active"));
      tabContents.forEach((c) => c.classList.remove("active"));

      tabBtn.classList.add("active");
      const targetEl = document.getElementById(targetId);
      if (targetEl) targetEl.classList.add("active");
    });
  });

  // 4. Mark Notification Read
  document.querySelectorAll(".btn-mark-read").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const notifId = btn.dataset.notifId;
      try {
        const response = await fetch("/api/mark-notification-read", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: notifId })
        });
        const data = await response.json();
        if (data.success) {
          const card = btn.closest(".notification-card");
          if (card) card.classList.remove("unread");
          btn.remove();
          showToast("Notification marked as read", "success");
          updateNavBadge();
        }
      } catch (err) {
        console.error("Error marking notification read:", err);
      }
    });
  });

  // 5. Mark All Notifications Read
  const markAllBtn = document.getElementById("btnMarkAllRead");
  if (markAllBtn) {
    markAllBtn.addEventListener("click", async () => {
      try {
        const response = await fetch("/api/mark-all-read", {
          method: "POST",
          headers: { "Content-Type": "application/json" }
        });
        const data = await response.json();
        if (data.success) {
          document.querySelectorAll(".notification-card").forEach((c) => c.classList.remove("unread"));
          document.querySelectorAll(".btn-mark-read").forEach((b) => b.remove());
          showToast("All notifications marked as read", "success");
          const navBadge = document.querySelector(".nav-badge");
          if (navBadge) navBadge.remove();
        }
      } catch (err) {
        console.error("Error marking all read:", err);
      }
    });
  }
});

// Toast Notifications Helper
function showToast(message, type = "info") {
  let container = document.getElementById("toastContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "toastContainer";
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function updateNavBadge() {
  const badge = document.querySelector(".nav-badge");
  if (badge) {
    let count = parseInt(badge.textContent.trim(), 10) || 0;
    if (count > 1) {
      badge.textContent = count - 1;
    } else {
      badge.remove();
    }
  }
}
