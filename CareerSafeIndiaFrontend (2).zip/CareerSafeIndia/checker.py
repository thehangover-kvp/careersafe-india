"""
CareerSafe India - Offer Checker Analysis Engine
Evaluates job and internship offers for common scam indicators targeted at Indian job seekers.
"""
import re
from typing import Dict, Any, List

# Known legitimate corporate domains for top Indian employers frequently impersonated
KNOWN_CORPORATE_DOMAINS = {
    "tcs": ["tcs.com"],
    "tata consultancy services": ["tcs.com"],
    "infosys": ["infosys.com"],
    "wipro": ["wipro.com"],
    "hcl": ["hcltech.com", "hcl.com"],
    "hcltech": ["hcltech.com"],
    "tech mahindra": ["techmahindra.com"],
    "cognizant": ["cognizant.com"],
    "accenture": ["accenture.com"],
    "ltimindtree": ["ltimindtree.com"],
    "capgemini": ["capgemini.com"],
    "google": ["google.com"],
    "microsoft": ["microsoft.com"],
    "amazon": ["amazon.com", "amazon.jobs"],
    "flipkart": ["flipkart.com"],
    "swiggy": ["swiggy.in", "swiggy.com"],
    "zomato": ["zomato.com"],
    "paytm": ["paytm.com"],
    "reliance": ["ril.com", "jio.com"],
    "deloitte": ["deloitte.com"],
    "pwc": ["pwc.com"],
    "ey": ["ey.com"],
    "kpmg": ["kpmg.com"]
}

PUBLIC_FREE_DOMAINS = [
    "gmail.com", "yahoo.com", "yahoo.in", "yahoo.co.in", 
    "outlook.com", "hotmail.com", "rediffmail.com", "zoho.com", 
    "icloud.com", "mail.com", "proton.me", "protonmail.com"
]

SUSPICIOUS_DOMAIN_TLDS = [
    ".xyz", ".top", ".buzz", ".work", ".site", ".click", 
    ".online", ".icu", ".monster", ".live", ".cc"
]

SCAM_KEYWORDS = [
    (r"(refundable|security)\s+(deposit|fee|amount|money)", "Demand for 'refundable security deposit' is the #1 recruitment scam pattern in India.", "critical"),
    (r"(laptop|equipment|asset)\s+(security|courier|delivery|dispatch|insurance)\s*(fee|charges|amount)", "Asking candidates to pay courier or security charges for office laptops is fraudulent.", "critical"),
    (r"(registration|gate\s*pass|entry|application|document\s*verification|id\s*card)\s*(fee|charges|cost|amount)", "Legitimate companies never charge registration, document verification, or gate pass fees.", "critical"),
    (r"(training|certification|orientation|course)\s*(fee|cost|charges)\s*(before|mandatory|prior|payable)", "Charging freshers for 'mandatory training' before employment is a disguised course-selling scheme.", "critical"),
    (r"(gpay|phonepe|paytm|upi\s*id|qr\s*code|bank\s*transfer|google\s*pay)", "Payment requests via personal UPI handles (PhonePe, GPay, Paytm) for job offers indicate scam operations.", "critical"),
    (r"(telegram|whatsapp)\s*(task|group|channel|daily\s*income|like\s*and\s*subscribe)", "Tasks involving Telegram/WhatsApp channels for daily pay or reviews are part of cyber task scams.", "critical"),
    (r"(data\s*entry|form\s*filling|sms\s*sending|typing\s*work)\s*(daily\s*payment|earn\s*hourly|2000|5000)", "High-paying simple data entry or typing jobs are standard phishing and advance-fee lures.", "high"),
    (r"(urgent|immediate|within\s*24\s*hours|limited\s*seats|last\s*chance\s*to\s*confirm)", "High-pressure urgency tactics are engineered to prevent candidates from verifying with family or mentors.", "medium"),
    (r"(no\s*interview|direct\s*selection|immediate\s*offer\s*letter|without\s*interview)", "Direct appointment letters without technical or HR interaction contradict established hiring practices.", "high"),
    (r"(crypto|usdt|bitcoin|wallet\s*recharge|investment)", "Any job offer mentioning cryptocurrency wallets, USDT, or recharge tasks is financial fraud.", "critical"),
]

POSITIVE_KEYWORDS = [
    (r"(provident\s*fund|epf|gratuity|mediclaim|health\s*insurance)", "Mentions standard statutory Indian employment benefits (EPF, gratuity, insurance)."),
    (r"(probation\s*period|performance\s*review|notice\s*period)", "Mentions standard corporate HR employment conditions."),
    (r"(code\s*of\s*conduct|non[\s-]disclosure|nda|intellectual\s*property)", "Includes standard professional enterprise governance clauses."),
    (r"(written\s*test|coding\s*round|technical\s*interview|managerial\s*round)", "Reflects structured multi-stage evaluation process."),
]

def analyze_offer(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main offer analysis engine.
    Computes a risk score from 0 (very low risk) to 100 (critical scam risk),
    enumerates specific red flags and green flags, and gives an actionable verdict.
    """
    company_name = str(data.get("company_name", "")).strip()
    job_title = str(data.get("job_title", "")).strip()
    recruiter_email = str(data.get("recruiter_email", "")).strip().lower()
    contact_mode = str(data.get("contact_mode", "")).strip()
    interview_process = str(data.get("interview_process", "")).strip()
    salary_offered = str(data.get("salary_offered", "")).strip()
    fee_demanded_type = str(data.get("fee_demanded_type", "None")).strip()
    
    try:
        fee_amount = float(data.get("fee_amount", 0) or 0)
    except (ValueError, TypeError):
        fee_amount = 0.0

    offer_text = str(data.get("offer_text", "")).strip()

    risk_score = 0
    red_flags: List[Dict[str, str]] = []
    green_flags: List[Dict[str, str]] = []

    # ----------------------------------------------------
    # RULE 1: Fee / Monetary Demand (The Golden Rule of Indian Job Safety)
    # ----------------------------------------------------
    if fee_demanded_type not in ["None", "No Fee", "", "0"] or fee_amount > 0:
        fee_score = 55
        if fee_amount > 1000:
            fee_score = 65
        risk_score += fee_score
        
        amt_str = f" of ₹{int(fee_amount):,}" if fee_amount > 0 else ""
        red_flags.append({
            "title": f"Upfront Payment Requested ({fee_demanded_type}{amt_str})",
            "description": f"The employer asks for money ({fee_demanded_type}). Under Indian labor norms and corporate best practices, no genuine company (TCS, Infosys, Wipro, Amazon, etc.) charges registration, training, verification, or laptop security fees. This is a severe scam indicator.",
            "severity": "critical"
        })
    else:
        green_flags.append({
            "title": "Zero Application or Joining Fee",
            "description": "No upfront monetary payment or security deposit is requested."
        })

    # ----------------------------------------------------
    # RULE 2: Recruiter Email Domain Verification
    # ----------------------------------------------------
    email_domain = ""
    if "@" in recruiter_email:
        email_domain = recruiter_email.split("@")[-1].strip().lower()

    if email_domain:
        # Check against free email services
        is_free_domain = any(email_domain == free_dom for free_dom in PUBLIC_FREE_DOMAINS)
        
        # Check if company claimed is a known enterprise
        norm_company = company_name.lower()
        matched_known_firm = None
        for firm_key, valid_domains in KNOWN_CORPORATE_DOMAINS.items():
            if firm_key in norm_company:
                matched_known_firm = (firm_key, valid_domains)
                break

        if matched_known_firm:
            firm_name, valid_domains = matched_known_firm
            if email_domain in valid_domains:
                risk_score -= 15
                green_flags.append({
                    "title": f"Verified Corporate Email Domain (@{email_domain})",
                    "description": f"The recruiter email matches the authentic domain for {company_name.title()}."
                })
            elif is_free_domain:
                risk_score += 35
                red_flags.append({
                    "title": f"Corporate Impersonation using Free Email (@{email_domain})",
                    "description": f"The recruiter claims to represent '{company_name}', but is writing from a public free email provider (@{email_domain}). Genuine recruiters from established corporations never use generic Gmail/Yahoo accounts for official communications.",
                    "severity": "critical"
                })
            else:
                # Could be a lookalike domain
                risk_score += 25
                red_flags.append({
                    "title": f"Suspicious or Unverified Domain (@{email_domain})",
                    "description": f"The sender domain '@{email_domain}' does not match the official domain(s) for {company_name.title()} ({', '.join(valid_domains)}). Scammers frequently register spoofed lookalike domains (e.g. tcs-careers-portal.xyz).",
                    "severity": "high"
                })
        else:
            # Generic company check
            if is_free_domain:
                risk_score += 20
                red_flags.append({
                    "title": f"Recruiter Uses Free Email Address (@{email_domain})",
                    "description": f"Official hiring is conducted through corporate domains. While early-stage bootstrapped founders may occasionally use Gmail, major firms and established startups always provide business email addresses.",
                    "severity": "medium"
                })
            elif any(email_domain.endswith(tld) for tld in SUSPICIOUS_DOMAIN_TLDS):
                risk_score += 25
                red_flags.append({
                    "title": f"High-Risk Top Level Domain (@{email_domain})",
                    "description": f"The recruiter domain uses an extension ({email_domain[email_domain.rfind('.'):]}) commonly associated with temporary phishing and disposable websites.",
                    "severity": "high"
                })
            else:
                green_flags.append({
                    "title": f"Custom Business Domain (@{email_domain})",
                    "description": "Recruiter is contacting you from a custom organizational domain."
                })

    # ----------------------------------------------------
    # RULE 3: Contact Channel & Initial Reach-out Mode
    # ----------------------------------------------------
    contact_lower = contact_mode.lower()
    if "telegram" in contact_lower:
        risk_score += 25
        red_flags.append({
            "title": "Recruitment Initiated via Telegram",
            "description": "Telegram is the primary channel for illegal task scams, fake part-time data entry rings, and identity theft in India due to high anonymity.",
            "severity": "critical"
        })
    elif "whatsapp" in contact_lower and ("unsolicited" in contact_lower or "unknown" in contact_lower or "direct" in contact_lower):
        risk_score += 20
        red_flags.append({
            "title": "Unsolicited WhatsApp Job Outreach",
            "description": "Receiving spontaneous job offers on WhatsApp without having applied through a verified job board or campus placement cell is a standard scam pattern.",
            "severity": "high"
        })
    elif any(term in contact_lower for term in ["sms", "bulk message", "instagram"]):
        risk_score += 15
        red_flags.append({
            "title": f"Informal Outreach Channel ({contact_mode})",
            "description": "Professional recruitment is typically communicated through verified email, campus placement cells, or official portal dashboards.",
            "severity": "medium"
        })
    elif any(term in contact_lower for term in ["official portal", "linkedin", "campus", "career site"]):
        risk_score -= 10
        green_flags.append({
            "title": f"Standard Recruitment Channel ({contact_mode})",
            "description": "Offer originated from a recognized, trackable career channel."
        })

    # ----------------------------------------------------
    # RULE 4: Interview & Evaluation Rigor
    # ----------------------------------------------------
    interview_lower = interview_process.lower()
    if any(k in interview_lower for k in ["no interview", "direct offer", "instant selection", "none"]):
        risk_score += 30
        red_flags.append({
            "title": "Direct Offer Without Meaningful Interview",
            "description": "Legitimate organizations do not issue formal appointment or internship letters without conducting at least one technical or HR assessment.",
            "severity": "critical"
        })
    elif any(k in interview_lower for k in ["chat only", "whatsapp chat", "form only", "typing test"]):
        risk_score += 20
        red_flags.append({
            "title": "Superficial Evaluation Process",
            "description": "Selection based purely on a short chat or generic Google Form without video/in-person conversation is an established hallmark of fake job networks.",
            "severity": "high"
        })
    elif any(k in interview_lower for k in ["multi-round", "technical round", "in-person", "campus interview", "coding assessment"]):
        risk_score -= 15
        green_flags.append({
            "title": "Structured Interview Process",
            "description": "The candidate was evaluated through multi-stage technical and behavioral interviews."
        })

    # ----------------------------------------------------
    # RULE 5: Unrealistic Compensation Patterns
    # ----------------------------------------------------
    salary_lower = salary_offered.lower()
    # Check for daily payment promises (e.g. ₹2000 - ₹5000 per day)
    if any(k in salary_lower for k in ["per day", "/day", "daily", "per hour", "/hr"]):
        if any(role_word in job_title.lower() for role_word in ["data entry", "typing", "review", "like", "part time", "assistant", "fresher"]):
            risk_score += 25
            red_flags.append({
                "title": "Unrealistic Daily/Hourly Wage Claim",
                "description": "Promises of earning ₹1,500 - ₹5,000 daily for basic typing or mobile tasks are standard bait used in cyber fraud.",
                "severity": "high"
            })

    # ----------------------------------------------------
    # RULE 6: Offer Text Regex Keyword Heuristics
    # ----------------------------------------------------
    combined_text = f"{offer_text} {job_title} {company_name}".lower()
    
    for pattern, reason, severity in SCAM_KEYWORDS:
        if re.search(pattern, combined_text, re.IGNORECASE):
            # Avoid duplicate fee red flag if already captured
            if "refundable" in pattern and fee_demanded_type not in ["None", "No Fee", ""]:
                continue
            weight = 25 if severity == "critical" else (18 if severity == "high" else 10)
            risk_score += weight
            red_flags.append({
                "title": f"Suspicious Keyword / Phrase Detected",
                "description": reason,
                "severity": severity
            })

    for pattern, benefit in POSITIVE_KEYWORDS:
        if re.search(pattern, combined_text, re.IGNORECASE):
            risk_score -= 5
            green_flags.append({
                "title": "Legitimate Contract Terms Detected",
                "description": benefit
            })

    # ----------------------------------------------------
    # Calculate Final Score and Risk Level
    # ----------------------------------------------------
    # Clamp score to 0 - 100 range
    final_score = max(5, min(100, risk_score))
    
    # If explicit fee demanded or laptop deposit requested, floor risk at 75
    if (fee_demanded_type not in ["None", "No Fee", "", "0"] and fee_amount > 0) or "refundable" in combined_text:
        final_score = max(final_score, 75)

    if final_score >= 75:
        risk_level = "CRITICAL"
        risk_color = "danger"
        verdict_title = "CRITICAL RISK: High Probability Scam Pattern"
        verdict_summary = "This offer exhibits classic fraudulent markers observed in Indian recruitment scams (e.g., upfront payment demands, impersonated domains, or unsolicited direct appointment). We strongly advise DO NOT SEND MONEY and DO NOT SHARE PERSONAL BANK DETAILS."
    elif final_score >= 50:
        risk_level = "HIGH"
        risk_color = "warning-high"
        verdict_title = "HIGH RISK: Multiple Strong Red Flags Detected"
        verdict_summary = "Several suspicious elements were detected. Legitimate corporate practices appear violated. Proceed with extreme skepticism and cross-verify directly on the employer's official career portal."
    elif final_score >= 25:
        risk_level = "MODERATE"
        risk_color = "warning-medium"
        verdict_title = "MODERATE RISK: Caution Advised"
        verdict_summary = "Some informal or ambiguous characteristics were identified. While it might be a small agency or startup, you should independently verify the employer identity before sharing sensitive documents."
    else:
        risk_level = "LOW"
        risk_color = "success"
        verdict_title = "LOW RISK: Consistent with Genuine Recruitment"
        verdict_summary = "The offer characteristics conform to standard corporate hiring norms in India. No advance fees or direct impersonation cues were found. Always maintain healthy vigilance."

    # Actionable safety recommendations
    recommendations = [
        "Never pay any money under any label (registration, laptop courier, training, gate pass, or document verification).",
        "Search the company's verified careers site (e.g., companyname.com/careers) and verify if the job ID or opening exists.",
        "Verify the recruiter's identity on LinkedIn — check their tenure, mutual connections, and official corporate email.",
        "Never send OTPs, bank account login credentials, or Aadhar/PAN photocopies until you have verified the employer.",
        "If you suspect fraud, report it immediately to the National Cyber Crime Reporting Portal at cybercrime.gov.in or call 1930."
    ]

    disclaimer = (
        "IMPORTANT LEGAL & SAFETY DISCLAIMER: CareerSafe India provides this analysis as an educational "
        "and initial screening advisory tool based on common fraudulent hiring patterns reported by Indian students. "
        "This tool is NOT a guaranteed fraud detector. A 'Low Risk' result does not constitute an endorsement or guarantee of legitimacy, "
        "and a 'High Risk' result is an advisory caution. Always independently cross-reference any job or internship offer "
        "with the official corporate careers portal, university placement cell, or state cyber cell."
    )

    return {
        "score": final_score,
        "risk_level": risk_level,
        "risk_color": risk_color,
        "verdict_title": verdict_title,
        "verdict_summary": verdict_summary,
        "red_flags": red_flags,
        "green_flags": green_flags,
        "recommendations": recommendations,
        "disclaimer": disclaimer,
        "inputs": {
            "company_name": company_name,
            "job_title": job_title,
            "recruiter_email": recruiter_email,
            "contact_mode": contact_mode,
            "salary_offered": salary_offered,
            "fee_demanded_type": fee_demanded_type,
            "fee_amount": fee_amount
        }
    }


def get_demo_presets() -> List[Dict[str, Any]]:
    """
    Returns curated sample presets to allow instant 1-click testing
    by students, recruiters, and evaluators.
    """
    return [
        {
            "id": "preset_laptop_scam",
            "label": "Demo Scam 1: Fake TCS ₹4,500 Laptop Deposit",
            "data": {
                "company_name": "Tata Consultancy Services (Demo Case)",
                "job_title": "Junior Python Developer / Associate",
                "recruiter_email": "tcs.hr.recruitment2026@gmail.com",
                "contact_mode": "Unsolicited WhatsApp Direct Message",
                "interview_process": "Direct offer letter without interview",
                "salary_offered": "₹6.5 LPA",
                "fee_demanded_type": "Laptop Security Deposit & Courier Fee",
                "fee_amount": 4500,
                "offer_text": (
                    "Dear Candidate, Congratulations! You have been selected for Tata Consultancy Services. "
                    "Salary is ₹6,50,000 per annum. Work from home mode. A brand new HP Core i7 laptop will be delivered to your address. "
                    "You must pay a refundable courier and asset security deposit of ₹4,500 to our logistics account via PhonePe/GPay "
                    "within 24 hours. The fee will be 100% refunded in your first salary slip. Hurry, offer valid today only."
                )
            }
        },
        {
            "id": "preset_telegram_task",
            "label": "Demo Scam 2: Part-time Telegram Data Entry & Daily Wage",
            "data": {
                "company_name": "Global Media Task Services (Demo Case)",
                "job_title": "Part-Time YouTube Review & Data Entry Associate",
                "recruiter_email": "hr@mediatask-online.xyz",
                "contact_mode": "Telegram Channel / Direct Message",
                "interview_process": "Chat only on Telegram",
                "salary_offered": "₹3,000 per day",
                "fee_demanded_type": "Registration Fee",
                "fee_amount": 1200,
                "offer_text": (
                    "Earn ₹3,000 to ₹5,000 daily from your smartphone! Simple tasks: like 10 YouTube videos and type 2 review forms. "
                    "Immediate daily payment. To activate your task wallet and VIP member code, send ₹1,200 registration fee to our coordinator UPI id. "
                    "Join Telegram channel @daily_income_india to receive tasks immediately."
                )
            }
        },
        {
            "id": "preset_fake_internship",
            "label": "Demo Scam 3: 'Pay for Certificate' Internship",
            "data": {
                "company_name": "Apex EdTech Solutions (Demo Case)",
                "job_title": "Web Development Intern",
                "recruiter_email": "careers.apextech@yahoo.in",
                "contact_mode": "Direct Instagram / WhatsApp Message",
                "interview_process": "Short Google Form only",
                "salary_offered": "Unpaid with Certificate",
                "fee_demanded_type": "Training & Certification Fee",
                "fee_amount": 1999,
                "offer_text": (
                    "Selected for 1-Month Virtual Internship in Full Stack Development! "
                    "Gain industry experience and ISO verified certificate with LOR. "
                    "Candidates must pay a mandatory training and mentor evaluation fee of ₹1,999 before joining the orientation batch. "
                    "Click here to pay and reserve your seat."
                )
            }
        },
        {
            "id": "preset_legit_tcs",
            "label": "Demo Safe Offer: Standard Verified Campus Offer",
            "data": {
                "company_name": "Tata Consultancy Services (Demo Safe Sample)",
                "job_title": "System Engineer / Ninja Trainee",
                "recruiter_email": "campus.recruitment@tcs.com",
                "contact_mode": "Official Portal / Campus Placement Cell",
                "interview_process": "Multi-round (NQT Written Assessment + Technical Interview + HR Round)",
                "salary_offered": "₹3.6 LPA",
                "fee_demanded_type": "None",
                "fee_amount": 0,
                "offer_text": (
                    "We are pleased to offer you employment with Tata Consultancy Services Limited as a System Engineer Trainee. "
                    "Your gross annual compensation will be ₹3,60,000 as detailed in the annexure. This offer is subject to satisfactory "
                    "background verification and verification of original educational credentials. TCS does not charge any fee at any stage "
                    "of the recruitment process. Please log in to TCS NextStep portal using your registered credentials to accept this offer."
                )
            }
        }
    ]
