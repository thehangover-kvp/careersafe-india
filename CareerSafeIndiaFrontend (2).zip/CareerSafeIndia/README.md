# 🛡️ CareerSafe India — Fake Job & Internship Detection System

**CareerSafe India** is a beginner-friendly web application designed to protect Indian college students, recent graduates, and entry-level job seekers from fraudulent recruitment schemes, advance-fee scams, and corporate impersonation networks.

---

## 🏷️ Standardized Verification Statuses

To ensure honesty and prevent misinformation, CareerSafe India classifies all company profiles and job/internship listings under 5 explicit statuses:

| Status | Badge | Description & Evidence Standard |
| :--- | :--- | :--- |
| **Demo** | `[Demo]` | Simulated sample data created strictly for student training and educational demonstration. Clearly marked with `[DEMO DATA]`. |
| **Official Source Linked** | `[Official Source Linked]` | Directly references an authenticated official corporate career portal (e.g. `tcs.com/careers`), but the specific individual vacancy requisition has not been independently audited. |
| **Verified** | `[Verified]` | **Only used when actual evidence supports it.** Requisition ID has been matched against active listings on the employer's canonical corporate ATS (e.g., Workday, Greenhouse, Taleo) or university placement circular. |
| **Expired** | `[Expired]` | Verified or linked opportunity whose application deadline has elapsed or requisition has been unlisted by the employer. |
| **Unable to Verify** | `[Unable to Verify]` | Entity or listing whose corporate registration (CIN), corporate domain, or physical address cannot be substantiated. |

> [!IMPORTANT]
> **Data Integrity Policy:** Never invent verified companies, job listings, or salaries. Sample listings must remain truthfully classified as `Demo`.

---

## 🌟 Key Features & Working Pages

1. **Home Page (`/`)**:
   - Modern, responsive landing page with Indian career protection branding.
   - Live fraud statistics (78% advance-fee prevalence, ₹0 genuine hiring cost standard).
   - 1-Click quick screening demo launcher.
   - Real-time campus fraud advisories and security alerts.
   - Highlights of sample demo opportunities with explicit status indicators.

2. **Company Safety Directory (`/companies` & `/companies/<slug>`)**:
   - Searchable directory of major employers (TCS, Infosys, Wipro, HCLTech, Freshworks, Swiggy, Zomato) and educational scam case studies.
   - Displays official corporate email domains (`@tcs.com`, `@infosys.com`).
   - Outlines official zero-fee hiring policies and active fraud advisories warning how scammers impersonate these brands.
   - **Verification & Source Audit Panel:** Shows verification status, official source link, last checked date, and full audit explanation.

3. **Job Finder with Safety Screening (`/jobs` & `/jobs/<id>`)**:
   - Filter jobs by keyword, technical domain, location, work mode, experience, and **verification status** (`Demo`, `Official Source Linked`, `Verified`, etc.).
   - Distinct `[DEMO DATA]` indicators on every sample entry.
   - Dedicated **Job Detail & Verification Audit View (`/jobs/<id>`)** detailing official source link, last checked date, and transparent verification notes.
   - Interactive 1-click **Save / Bookmark** feature.

4. **Student Internship Finder (`/internships` & `/internships/<id>`)**:
   - Filter internships by domain, duration, stipend, work mode, and verification status.
   - Critical student advisory warning against predatory "Pay-to-Learn" certificate rackets.
   - Dedicated **Internship Detail & Verification Audit View (`/internships/<id>`)**.

5. **Fake Job & Internship Offer Checker (`/checker`)**:
   - Intelligent screening engine checking for:
     - **Advance-Fee Demands:** Registration charges, laptop security deposits, gate pass fees, training fees.
     - **Recruiter Email Spoofing:** Detects free `@gmail.com` or lookalike domains impersonating top companies.
     - **Unsolicited Channels:** Telegram channels and unsolicited WhatsApp offers.
     - **Evaluation Rigor:** Direct appointment letters without technical or HR interviews.
     - **Unrealistic Compensation:** Lures such as ₹3,000/day for data entry or video review tasks.
   - Output includes:
     - Numerical Risk Score (0 - 100%)
     - Color-coded Risk Level Badge (`LOW`, `MODERATE`, `HIGH`, `CRITICAL`)
     - Itemized Red Flags & Green Flags breakdowns with clear explanations
     - Student Action Checklist
     - **Mandatory Advisory Disclaimer** explicitly stating this is an educational screening tool, not a guaranteed fraud detector.
   - **4 Instant 1-Click Presets** to test different scenarios:
     1. *Fake TCS ₹4,500 Laptop Deposit Scam* (Critical 100% Risk)
     2. *Telegram Part-Time Daily Wage Scam* (Critical Risk)
     3. *EdTech Pay-to-Get Certificate Scam* (High Risk)
     4. *Standard Verified Campus Offer* (Low Risk 5%)

6. **User Dashboard (`/dashboard`)**:
   - **Saved Jobs & Internships:** View and manage bookmarked opportunities.
   - **Offer Scan History:** Track previously screened letters with risk scores and dates.
   - **In-App Notification Center:** Campus scam alerts and safety bulletins with single-click dismiss and "Mark All as Read" controls.

7. **Community Scam Reporting (`/report-scam`) & Safety Manual (`/about-safety`)**:
   - Enables students to document fraudulent recruiter phone numbers, UPI handles, and fake domains.
   - Comprehensive safety guide detailing the top 5 recruitment scam types in India, MCA verification, and how to contact the National Cyber Crime Helpline (**1930** / `cybercrime.gov.in`).

---

## 📋 Adding and Checking Real Listings

When transitioning from sample demo data to verified real listings, follow these mandatory auditing steps:

### 1. Verification Checklist Before Adding Any Real Listing
1. **Canonical Domain Verification:** Check that the recruiter or portal is hosted directly on the employer's official registered domain (e.g., `company.com/careers`), never a third-party redirect or lookalike TLD (`.xyz`, `.top`, `.click`).
2. **Ministry of Corporate Affairs (MCA) Lookup:** For Indian entities, verify the Company Identification Number (CIN) on `mca.gov.in`.
3. **Requisition ID Check:** Verify that the listing contains a verifiable Job ID in the corporate Applicant Tracking System (ATS).
4. **Zero-Fee Policy:** Confirm that applying involves **₹0** fees. Any opportunity charging for tests, gate passes, or training is prohibited.
5. **Ethical Compliance:** Do not scrape career websites in ways that violate their terms of service, robots.txt, or authentication walls.

### 2. How to Add a Real Listing via Python / Database Script
To add an audited real listing into `careersafe.db`, populate the required audit fields:

```python
import database as db

conn = db.get_db_connection()
cur = conn.cursor()

# Example: Adding a Verified Real Job
cur.execute("""
    INSERT INTO jobs (
        company_id, title, domain, location, work_type, work_mode,
        experience_level, salary_range, description, requirements,
        safety_verified, verification_status, verification_notes,
        source_url, last_checked_date, is_demo, official_apply_url, posted_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
""", (
    1,                                      # company_id
    "Associate Software Engineer",          # title
    "Software Engineering",                 # domain
    "Bengaluru, Karnataka",                 # location
    "Full-Time",                            # work_type
    "Hybrid",                               # work_mode
    "Fresher (0-1 yrs)",                    # experience_level
    "Competitive (As per corporate norms)", # salary_range (do not invent unverified figures)
    "Full-time engineering role verified on corporate portal.", # description
    "B.Tech/B.E in CS/IT. Validated on official careers site.",  # requirements
    1,                                      # safety_verified (1 only if evidence verified)
    "Verified",                             # verification_status ('Verified' or 'Official Source Linked')
    "Verified against official corporate ATS requisition #TCS-2026-8812. Zero fee confirmed.", # verification_notes
    "https://www.tcs.com/careers/india",    # source_url (Official verifiable URL)
    "2026-10-20",                           # last_checked_date (YYYY-MM-DD)
    0,                                      # is_demo (0 for real data, 1 for sample)
    "https://www.tcs.com/careers/india",    # official_apply_url
    "Today"                                 # posted_date
))
conn.commit()
conn.close()
```

---

## 🛠️ Tech Stack

- **Backend:** Python 3.10+ / Flask 3.x
- **Database:** SQLite3 (Embedded, zero-configuration)
- **Frontend:** HTML5, CSS3 (Modern custom responsive stylesheet), Vanilla JavaScript (Zero npm dependencies)
- **Testing:** Python `unittest` framework (26 automated test cases)

---

## 🚀 Simple Windows Instructions to Run the Application

Follow these easy steps in Windows PowerShell or Command Prompt:

### Step 1: Open PowerShell in the Project Directory
Press `Win + R`, type `powershell`, and run:
```powershell
cd C:\Users\annab\OneDrive\Desktop\CareerSafeIndia
```

### Step 2: Verify Python and Pip
Check that Python is installed:
```powershell
py --version
```
*Output should show Python 3.10 or higher (e.g., Python 3.14).*

### Step 3: Install Required Dependencies
Run:
```powershell
py -m pip install -r requirements.txt
```
*What this does:* Installs Flask and its lightweight core dependencies.

### Step 4: Run the Automated Test Suite
Run:
```powershell
py -m unittest tests/test_app.py -v
```
*What this does:* Executes **26 automated tests** verifying database schema migrations, verification audit integrity, the scam detection heuristics engine, and all Flask routes. You should see `OK`.

### Step 5: Start the Web Application
Run:
```powershell
py app.py
```
*What this does:* Starts the local development server. You will see output like:
```text
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://127.0.0.1:5000
```

### Step 6: Open the Application in Your Browser
Open your preferred browser (Chrome, Edge, Firefox) and navigate to:
```text
http://127.0.0.1:5000
```

---

## 🔒 Ethical Notice & Disclaimer

- **Demo Data Standard:** In compliance with ethical safety requirements, all mock listings and simulated profiles are clearly labelled as demonstration sample data (`[DEMO DATA]`). No actual monetary transactions or commercial hiring take place directly on this prototype.
- **Initial Screening Disclaimer:** CareerSafe India provides an educational and advisory screening system based on known recruitment fraud signatures in India. Users are always advised to cross-verify offers directly on verified official corporate portals or through university placement cells.
