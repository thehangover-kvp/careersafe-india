"""
CareerSafe India - Database Setup and Operations
Uses SQLite to store companies, jobs, internships, user scan history,
saved items, notifications, and scam reports.

Features explicit verification statuses:
- Demo: Sample/demo records for student demonstration and curriculum.
- Official Source Linked: Sourced with direct link to official career portal.
- Verified: Supported by independent authenticated evidence from official corporate requisition.
- Expired: Opportunity has closed or application window elapsed.
- Unable to Verify: Source cannot be validated or claims are ambiguous.
"""
import sqlite3
import os
from datetime import datetime
from typing import List, Dict, Any, Optional

# Valid verification statuses
VALID_VERIFICATION_STATUSES = [
    "Demo",
    "Official Source Linked",
    "Verified",
    "Expired",
    "Unable to Verify"
]

def get_db_connection(db_path: str = "careersafe.db") -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path: str = "careersafe.db"):
    """Creates the SQLite database schema if not present, applies migrations, and seeds initial data."""
    conn = get_db_connection(db_path)
    cur = conn.cursor()

    # 1. Companies Table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT UNIQUE NOT NULL,
            industry TEXT NOT NULL,
            headquarters TEXT NOT NULL,
            official_website TEXT NOT NULL,
            official_career_portal TEXT NOT NULL,
            legitimate_domains TEXT NOT NULL,
            recruitment_policy TEXT NOT NULL,
            known_scam_tactics TEXT NOT NULL,
            verification_status TEXT NOT NULL DEFAULT 'Demo',
            verification_notes TEXT NOT NULL DEFAULT '',
            source_url TEXT NOT NULL DEFAULT '',
            last_checked_date TEXT NOT NULL DEFAULT '',
            is_demo INTEGER NOT NULL DEFAULT 1,
            description TEXT NOT NULL,
            trust_score INTEGER NOT NULL DEFAULT 95
        )
    """)

    # 2. Jobs Table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            domain TEXT NOT NULL,
            location TEXT NOT NULL,
            work_type TEXT NOT NULL,
            work_mode TEXT NOT NULL,
            experience_level TEXT NOT NULL,
            salary_range TEXT NOT NULL,
            description TEXT NOT NULL,
            requirements TEXT NOT NULL,
            safety_verified INTEGER NOT NULL DEFAULT 0,
            verification_status TEXT NOT NULL DEFAULT 'Demo',
            verification_notes TEXT NOT NULL DEFAULT '',
            source_url TEXT NOT NULL DEFAULT '',
            last_checked_date TEXT NOT NULL DEFAULT '',
            is_demo INTEGER NOT NULL DEFAULT 1,
            official_apply_url TEXT NOT NULL,
            posted_date TEXT NOT NULL,
            FOREIGN KEY (company_id) REFERENCES companies (id)
        )
    """)

    # 3. Internships Table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS internships (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            domain TEXT NOT NULL,
            location TEXT NOT NULL,
            work_mode TEXT NOT NULL,
            duration TEXT NOT NULL,
            stipend_amount INTEGER NOT NULL,
            stipend_display TEXT NOT NULL,
            is_paid INTEGER NOT NULL DEFAULT 1,
            requires_fee INTEGER NOT NULL DEFAULT 0,
            eligibility TEXT NOT NULL,
            perks TEXT NOT NULL,
            description TEXT NOT NULL,
            safety_verified INTEGER NOT NULL DEFAULT 0,
            verification_status TEXT NOT NULL DEFAULT 'Demo',
            verification_notes TEXT NOT NULL DEFAULT '',
            source_url TEXT NOT NULL DEFAULT '',
            last_checked_date TEXT NOT NULL DEFAULT '',
            is_demo INTEGER NOT NULL DEFAULT 1,
            official_apply_url TEXT NOT NULL,
            posted_date TEXT NOT NULL,
            FOREIGN KEY (company_id) REFERENCES companies (id)
        )
    """)

    # 4. Saved Items Table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS saved_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_type TEXT NOT NULL,
            item_id INTEGER NOT NULL,
            saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(item_type, item_id)
        )
    """)

    # 5. Offer Scans Table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS offer_scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_name TEXT NOT NULL,
            job_title TEXT NOT NULL,
            recruiter_email TEXT,
            salary_offered TEXT,
            fee_demanded_type TEXT,
            fee_amount REAL DEFAULT 0,
            risk_score INTEGER NOT NULL,
            risk_level TEXT NOT NULL,
            verdict_title TEXT NOT NULL,
            verdict_summary TEXT NOT NULL,
            scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 6. Notifications Table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            message TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'info',
            date_posted TEXT NOT NULL,
            is_read INTEGER NOT NULL DEFAULT 0
        )
    """)

    # 7. Scam Reports Table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS scam_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scammer_name TEXT,
            company_impersonated TEXT NOT NULL,
            contact_method TEXT NOT NULL,
            email_or_phone TEXT,
            amount_demanded TEXT,
            details TEXT NOT NULL,
            reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()

    # Apply column migrations for existing databases
    migrate_schema(conn)

    # Seed demo data if companies table is empty
    cur.execute("SELECT COUNT(*) FROM companies")
    if cur.fetchone()[0] == 0:
        seed_demo_data(conn)
    else:
        # Ensure existing demo data is properly upgraded with truthful statuses
        upgrade_existing_demo_records(conn)

    conn.close()


def migrate_schema(conn: sqlite3.Connection):
    """Adds missing columns if the database existed prior to verification audit updates."""
    cur = conn.cursor()

    # Check companies table columns
    cur.execute("PRAGMA table_info(companies)")
    comp_cols = {r[1] for r in cur.fetchall()}
    if "source_url" not in comp_cols:
        cur.execute("ALTER TABLE companies ADD COLUMN source_url TEXT NOT NULL DEFAULT ''")
    if "last_checked_date" not in comp_cols:
        cur.execute("ALTER TABLE companies ADD COLUMN last_checked_date TEXT NOT NULL DEFAULT ''")
    if "verification_notes" not in comp_cols:
        cur.execute("ALTER TABLE companies ADD COLUMN verification_notes TEXT NOT NULL DEFAULT ''")

    # Check jobs table columns
    cur.execute("PRAGMA table_info(jobs)")
    job_cols = {r[1] for r in cur.fetchall()}
    if "source_url" not in job_cols:
        cur.execute("ALTER TABLE jobs ADD COLUMN source_url TEXT NOT NULL DEFAULT ''")
    if "last_checked_date" not in job_cols:
        cur.execute("ALTER TABLE jobs ADD COLUMN last_checked_date TEXT NOT NULL DEFAULT ''")
    if "verification_status" not in job_cols:
        cur.execute("ALTER TABLE jobs ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'Demo'")
    if "verification_notes" not in job_cols:
        cur.execute("ALTER TABLE jobs ADD COLUMN verification_notes TEXT NOT NULL DEFAULT ''")

    # Check internships table columns
    cur.execute("PRAGMA table_info(internships)")
    intern_cols = {r[1] for r in cur.fetchall()}
    if "source_url" not in intern_cols:
        cur.execute("ALTER TABLE internships ADD COLUMN source_url TEXT NOT NULL DEFAULT ''")
    if "last_checked_date" not in intern_cols:
        cur.execute("ALTER TABLE internships ADD COLUMN last_checked_date TEXT NOT NULL DEFAULT ''")
    if "verification_status" not in intern_cols:
        cur.execute("ALTER TABLE internships ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'Demo'")
    if "verification_notes" not in intern_cols:
        cur.execute("ALTER TABLE internships ADD COLUMN verification_notes TEXT NOT NULL DEFAULT ''")

    conn.commit()


def upgrade_existing_demo_records(conn: sqlite3.Connection):
    """Ensures existing demo records never falsely claim to be 'Verified' and have explicit source links and dates."""
    cur = conn.cursor()
    # Update companies with official source linked / demo statuses
    cur.execute("""
        UPDATE companies
        SET verification_status = 'Official Source Linked',
            source_url = official_career_portal,
            last_checked_date = '2026-10-20',
            verification_notes = 'Corporate domain, zero-fee hiring guidelines, and career portal link audited against public official registries. Profile represents demo reference data.'
        WHERE id IN (1, 2, 3, 4, 5, 6, 7)
    """)
    cur.execute("""
        UPDATE companies
        SET verification_status = 'Unable to Verify',
            source_url = 'https://example.com/unverified-careers',
            last_checked_date = '2026-10-20',
            verification_notes = 'Simulated high-risk case study. Recruiter domain and corporate address are unverified.'
        WHERE id = 8
    """)

    # Update jobs with explicit 'Demo' status
    cur.execute("""
        UPDATE jobs
        SET verification_status = 'Demo',
            source_url = official_apply_url,
            last_checked_date = '2026-10-20',
            safety_verified = 0,
            verification_notes = 'DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.'
        WHERE is_demo = 1
    """)

    # Update internships with explicit 'Demo' status
    cur.execute("""
        UPDATE internships
        SET verification_status = 'Demo',
            source_url = official_apply_url,
            last_checked_date = '2026-10-20',
            safety_verified = 0,
            verification_notes = 'DEMO DATA: Illustrative zero-fee internship curriculum model. Not an active corporate vacancy. For live opportunities, visit the official career portal source link.'
        WHERE is_demo = 1
    """)

    conn.commit()


def seed_demo_data(conn: sqlite3.Connection):
    """Inserts realistic sample data clearly tagged as Demo Data."""
    cur = conn.cursor()

    # Demo Companies: Verified against official public career portals
    companies_data = [
        (
            1,
            "Tata Consultancy Services (Demo Profile)",
            "tata-consultancy-services",
            "IT Services & Consulting",
            "Mumbai, Maharashtra",
            "https://www.tcs.com",
            "https://www.tcs.com/careers/india",
            "tcs.com",
            "TCS strictly operates a ZERO-FEE recruitment policy. All campus and off-campus communication is routed via verified @tcs.com emails or the official TCS NextStep portal. TCS NEVER requests money for interviews, gate passes, laptops, or document verification.",
            "Scammers regularly impersonate TCS HR on WhatsApp or Telegram offering direct job letters and demanding ₹3,000 - ₹5,000 as refundable laptop dispatch security fees.",
            "Official Source Linked",
            "Official corporate domain (@tcs.com) and NextStep recruitment portal verified against official public company disclosures. Profile provided as educational demo reference.",
            "https://www.tcs.com/careers/india",
            "2026-10-20",
            1,
            "Tata Consultancy Services is an Indian multinational information technology services and consulting firm headquartered in Mumbai, operating in 150 locations across 46 countries.",
            98
        ),
        (
            2,
            "Infosys Limited (Demo Profile)",
            "infosys-limited",
            "IT Services & Consulting",
            "Bengaluru, Karnataka",
            "https://www.infosys.com",
            "https://www.infosys.com/careers.html",
            "infosys.com",
            "Infosys follows a structured multi-stage evaluation process (Springboard, InfyTQ, Campus Hackathons). Infosys does not charge recruitment fees, deposit fees, or training costs from applicants under any circumstances.",
            "Fake offer letters with fabricated seal claiming to be Infosys HR, sent from free Gmail or Yahoo accounts, requiring ₹2,500 training registration fees.",
            "Official Source Linked",
            "Official corporate domain (@infosys.com) and careers portal verified against public corporate filings. Profile provided as educational demo reference.",
            "https://www.infosys.com/careers.html",
            "2026-10-20",
            1,
            "Infosys Limited is a global leader in next-generation digital services and consulting headquartered in Bengaluru.",
            98
        ),
        (
            3,
            "Wipro Enterprises (Demo Profile)",
            "wipro-enterprises",
            "Information Technology & BPO",
            "Bengaluru, Karnataka",
            "https://www.wipro.com",
            "https://careers.wipro.com",
            "wipro.com",
            "Wipro explicitly states that employment offers are published exclusively on careers.wipro.com. Wipro does not solicit security money or test administration fees.",
            "Fraudulent recruiters soliciting candidates via Telegram for 'Wipro Virtual Typing Projects' charging ₹1,000 for server access keys.",
            "Official Source Linked",
            "Official domain (@wipro.com) and corporate applicant portal verified against public domain registries. Profile provided as educational demo reference.",
            "https://careers.wipro.com",
            "2026-10-20",
            1,
            "Wipro is a prominent Indian multinational corporation that provides IT, consulting, and business process services.",
            96
        ),
        (
            4,
            "HCLTech (Demo Profile)",
            "hcltech",
            "IT Consulting & Engineering",
            "Noida, Uttar Pradesh",
            "https://www.hcltech.com",
            "https://www.hcltech.com/careers",
            "hcltech.com, hcl.com",
            "Recruits via structured assessments (HCL First Careers / Campus Drives). Candidates are never asked to pay for interview clearances or hardware shipping.",
            "Impersonators using @hcl-recruitment-careers.xyz to issue counterfeit appointment letters.",
            "Official Source Linked",
            "Official domain (@hcltech.com) and career portal verified against enterprise registries. Profile provided as educational demo reference.",
            "https://www.hcltech.com/careers",
            "2026-10-20",
            1,
            "HCLTech is a global technology company headquartered in Noida, delivering engineering, cloud, and digital services.",
            96
        ),
        (
            5,
            "Freshworks Technologies (Demo Profile)",
            "freshworks-technologies",
            "SaaS & Enterprise Cloud",
            "Chennai, Tamil Nadu",
            "https://www.freshworks.com",
            "https://www.freshworks.com/company/careers",
            "freshworks.com",
            "Zero recruitment fees. Hiring is managed via greenhouse.io portals linked through freshworks.com. Offers come directly from corporate recruiters.",
            "Scam ads on Instagram advertising 'Freshworks Customer Chat Support WFH' demanding ₹800 software tool license fees.",
            "Official Source Linked",
            "Official domain (@freshworks.com) and careers portal verified against official public sources. Profile provided as educational demo reference.",
            "https://www.freshworks.com/company/careers",
            "2026-10-20",
            1,
            "Freshworks creates AI-driven business software for customer support, IT service management, and CRM, founded in Chennai.",
            95
        ),
        (
            6,
            "Swiggy Delivery & Tech (Demo Profile)",
            "swiggy-tech",
            "Food Delivery & Quick Commerce",
            "Bengaluru, Karnataka",
            "https://www.swiggy.com",
            "https://careers.swiggy.com",
            "swiggy.in, swiggy.com",
            "Zero hiring fees for corporate, engineering, and product roles. Official hiring is conducted via standard applicant tracking systems.",
            "Unsolicited WhatsApp messages offering 'Swiggy Online Menu Tagging - ₹2,500/day' requesting an initial UPI security deposit.",
            "Official Source Linked",
            "Official corporate domains (@swiggy.in, @swiggy.com) and applicant tracking portals verified against public company registries.",
            "https://careers.swiggy.com",
            "2026-10-20",
            1,
            "Swiggy is one of India's leading on-demand convenience platforms operating food delivery and Instamart quick commerce.",
            94
        ),
        (
            7,
            "Zomato Limited (Demo Profile)",
            "zomato-limited",
            "Consumer Tech & Logistics",
            "Gurugram, Haryana",
            "https://www.zomato.com",
            "https://www.zomato.com/careers",
            "zomato.com",
            "Zero fees. Recruitment is communicated exclusively via verified @zomato.com domains and official hiring channels.",
            "Fake part-time restaurant review scam rings claiming to be Zomato affiliate programs operating on Telegram.",
            "Official Source Linked",
            "Official domain (@zomato.com) and corporate careers website verified against public company listings.",
            "https://www.zomato.com/careers",
            "2026-10-20",
            1,
            "Zomato connects consumers with restaurants and delivery partners across hundreds of Indian cities.",
            94
        ),
        (
            8,
            "Apex Global Tech (Demo Impersonation Case Study)",
            "apex-global-tech-case-study",
            "Simulated Fraud Case Study",
            "Unverified Address",
            "https://example.com/unverified",
            "https://example.com/unverified-careers",
            "gmail.com, apextech.xyz",
            "CRITICAL WARNING: This is a simulated high-risk entity model created for student training. Genuine companies do not demand UPI fees or interview gate passes.",
            "Demands ₹2,500 registration deposit via UPI and issues appointment letters without an interview.",
            "Unable to Verify",
            "Demonstration fraud case study. Corporate registration (CIN), corporate domain, and physical workplace address cannot be verified.",
            "https://example.com/unverified-careers",
            "2026-10-20",
            1,
            "Educational case-study profile illustrating how fraudulent recruitment agencies pose with generic names and lookalike credentials.",
            15
        )
    ]

    cur.executemany("""
        INSERT INTO companies (
            id, name, slug, industry, headquarters, official_website,
            official_career_portal, legitimate_domains, recruitment_policy,
            known_scam_tactics, verification_status, verification_notes,
            source_url, last_checked_date, is_demo, description, trust_score
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, companies_data)

    # Demo Jobs: Explicitly tagged as Demo with source links and notes
    jobs_data = [
        (
            1,
            "Graduate Trainee Engineer - Software [DEMO DATA]",
            "Software Engineering",
            "Bengaluru, Karnataka",
            "Full-Time",
            "Hybrid",
            "Fresher (0-1 yrs)",
            "₹4.5 - ₹6.0 LPA",
            "Exciting entry-level opportunity for graduating computer science and IT students to work on enterprise cloud applications, modern API architecture, and microservices.",
            "B.Tech/B.E/MCA in Computer Science, IT or related fields; Knowledge of Java/Python, Data Structures, and SQL; Zero fee involved.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://www.tcs.com/careers/india",
            "2026-10-20",
            1,
            "https://www.tcs.com/careers/india",
            "2 days ago"
        ),
        (
            1,
            "Associate Quality Assurance Engineer [DEMO DATA]",
            "Software Engineering",
            "Pune, Maharashtra",
            "Full-Time",
            "In-Office",
            "Fresher (0-1 yrs)",
            "₹3.8 - ₹4.8 LPA",
            "Participate in test automation suites, test script execution, and regression testing for high-availability systems.",
            "Basic understanding of Selenium, Python/Java, and manual testing concepts; Good communication skills.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://www.tcs.com/careers/india",
            "2026-10-20",
            1,
            "https://www.tcs.com/careers/india",
            "3 days ago"
        ),
        (
            2,
            "Systems Engineer - Cloud & DevOps [DEMO DATA]",
            "Cloud & Infrastructure",
            "Hyderabad, Telangana",
            "Full-Time",
            "Hybrid",
            "Fresher to 1 yr",
            "₹4.2 - ₹5.5 LPA",
            "Support enterprise cloud deployments, CI/CD pipeline automation, and Linux environment configurations in a collaborative global team.",
            "Familiarity with AWS/Azure basics, Linux commands, shell scripting, and Git version control.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://www.infosys.com/careers.html",
            "2026-10-20",
            1,
            "https://www.infosys.com/careers.html",
            "1 day ago"
        ),
        (
            2,
            "Junior Data Analyst [DEMO DATA]",
            "Data Analytics",
            "Bengaluru, Karnataka",
            "Full-Time",
            "Hybrid",
            "Fresher (0-1 yrs)",
            "₹4.5 - ₹5.8 LPA",
            "Collaborate with business intelligence teams to build dashboards, clean dataset pipelines, and generate actionable reporting metrics.",
            "Strong command of SQL, Excel, and PowerBI or Tableau; Python (Pandas) is a plus.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://www.infosys.com/careers.html",
            "2026-10-20",
            1,
            "https://www.infosys.com/careers.html",
            "4 days ago"
        ),
        (
            3,
            "Cybersecurity Associate [DEMO DATA]",
            "Cybersecurity",
            "Noida, Uttar Pradesh",
            "Full-Time",
            "In-Office",
            "Fresher to 2 yrs",
            "₹5.0 - ₹6.8 LPA",
            "Monitor security alerts, conduct threat vulnerability scans, and assist senior analysts in defending enterprise infrastructure.",
            "B.Tech or BCA; understanding of network protocols, firewalls, OWASP Top 10, and SIEM logging fundamentals.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://careers.wipro.com",
            "2026-10-20",
            1,
            "https://careers.wipro.com",
            "Just now"
        ),
        (
            4,
            "Frontend Engineer - React.js [DEMO DATA]",
            "Software Engineering",
            "Chennai, Tamil Nadu",
            "Full-Time",
            "Remote",
            "Fresher (0-1 yrs)",
            "₹4.8 - ₹6.5 LPA",
            "Build responsive user interfaces, integrate RESTful web services, and optimize frontend web performance for modern client applications.",
            "Proficiency in JavaScript (ES6+), React.js, HTML5, and CSS3; Experience with Git.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://www.hcltech.com/careers",
            "2026-10-20",
            1,
            "https://www.hcltech.com/careers",
            "5 days ago"
        ),
        (
            5,
            "Product Support Specialist [DEMO DATA]",
            "Customer Success & IT",
            "Chennai, Tamil Nadu",
            "Full-Time",
            "Hybrid",
            "Fresher (0-1 yrs)",
            "₹4.0 - ₹5.2 LPA",
            "Assist global enterprise clients in troubleshooting product workflows, configuring integrations, and diagnosing API errors.",
            "Strong verbal and written English communication; problem-solving aptitude; basic web troubleshooting ability.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://www.freshworks.com/company/careers",
            "2026-10-20",
            1,
            "https://www.freshworks.com/company/careers",
            "3 days ago"
        ),
        (
            6,
            "Junior Operations Analyst [DEMO DATA]",
            "Operations & Logistics",
            "Bengaluru, Karnataka",
            "Full-Time",
            "In-Office",
            "Fresher (0-1 yrs)",
            "₹4.2 - ₹5.5 LPA",
            "Analyze fleet allocation, delivery turnaround times, and merchant fulfillment metrics to improve daily logistics efficiency.",
            "Degree in Engineering, Math, or Business; strong analytical mindset and data visualization skills.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://careers.swiggy.com",
            "2026-10-20",
            1,
            "https://careers.swiggy.com",
            "2 days ago"
        ),
        (
            7,
            "Growth & Marketing Associate [DEMO DATA]",
            "Digital Marketing",
            "Gurugram, Haryana",
            "Full-Time",
            "In-Office",
            "Fresher (0-1 yrs)",
            "₹4.5 - ₹5.8 LPA",
            "Plan campus outreach campaigns, analyze user conversion funnels, and assist in creative content distribution.",
            "Enthusiasm for consumer tech, social media trends, and marketing analytics.",
            0,
            "Demo",
            "DEMO DATA: Simulated entry-level opportunity for educational demonstration. Not an active corporate vacancy. For live openings, consult the official career portal source link.",
            "https://www.zomato.com/careers",
            "2026-10-20",
            1,
            "https://www.zomato.com/careers",
            "6 days ago"
        )
    ]

    cur.executemany("""
        INSERT INTO jobs (
            company_id, title, domain, location, work_type, work_mode,
            experience_level, salary_range, description, requirements,
            safety_verified, verification_status, verification_notes,
            source_url, last_checked_date, is_demo, official_apply_url, posted_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, jobs_data)

    # Demo Internships
    internships_data = [
        (
            1,
            "Python Backend Development Intern [DEMO DATA]",
            "Software Engineering",
            "Bengaluru, Karnataka",
            "Virtual / Remote",
            "3 Months",
            18000,
            "₹18,000 / month",
            1, 0,
            "Pre-final / Final year students in Computer Science, IT, or Electronics",
            "Stipend, Certificate of Completion, Pre-Placement Interview (PPI) opportunity, 1-on-1 Mentorship",
            "Work alongside senior software architects on scalable Python microservices, database schemas, and unit testing frameworks. 100% Free - Genuine internships never ask for fees.",
            0,
            "Demo",
            "DEMO DATA: Illustrative zero-fee internship curriculum model. Not an active corporate vacancy. For live opportunities, visit the official career portal source link.",
            "https://www.tcs.com/careers/india",
            "2026-10-20",
            1,
            "https://www.tcs.com/careers/india",
            "2 days ago"
        ),
        (
            2,
            "Full Stack Web Development Intern [DEMO DATA]",
            "Software Engineering",
            "Pune, Maharashtra",
            "Hybrid",
            "6 Months",
            15000,
            "₹15,000 / month",
            1, 0,
            "Undergraduate students with basic HTML/CSS/JavaScript and backend familiarity",
            "Monthly Stipend, Industry Project Certificate, Flexible Hours",
            "Build user-centric modules for enterprise portals using modern JavaScript frameworks and REST APIs. Zero training or joining fee.",
            0,
            "Demo",
            "DEMO DATA: Illustrative zero-fee internship curriculum model. Not an active corporate vacancy. For live opportunities, visit the official career portal source link.",
            "https://www.infosys.com/careers.html",
            "2026-10-20",
            1,
            "https://www.infosys.com/careers.html",
            "1 day ago"
        ),
        (
            3,
            "Machine Learning & AI Research Intern [DEMO DATA]",
            "Data Analytics & AI",
            "Bengaluru, Karnataka",
            "Virtual / Remote",
            "3 Months",
            22000,
            "₹22,000 / month",
            1, 0,
            "Students pursuing B.Tech/M.Tech with foundational linear algebra, Python, and PyTorch/TensorFlow",
            "High Stipend, Research Co-authorship potential, Work from Home allowance",
            "Contribute to NLP and document understanding pipelines. Evaluated through a fair, transparent coding test with zero application fees.",
            0,
            "Demo",
            "DEMO DATA: Illustrative zero-fee internship curriculum model. Not an active corporate vacancy. For live opportunities, visit the official career portal source link.",
            "https://careers.wipro.com",
            "2026-10-20",
            1,
            "https://careers.wipro.com",
            "Just now"
        ),
        (
            5,
            "UI/UX Design & User Research Intern [DEMO DATA]",
            "Design & Product",
            "Chennai, Tamil Nadu",
            "In-Office",
            "3 Months",
            16000,
            "₹16,000 / month",
            1, 0,
            "Design students or self-taught creators with a portfolio in Figma",
            "Stipend, Figma Enterprise Access, Free Cafeteria Lunch, Portfolio mentorship",
            "Craft interactive prototypes, wireframes, and design system components for B2B cloud products.",
            0,
            "Demo",
            "DEMO DATA: Illustrative zero-fee internship curriculum model. Not an active corporate vacancy. For live opportunities, visit the official career portal source link.",
            "https://www.freshworks.com/company/careers",
            "2026-10-20",
            1,
            "https://www.freshworks.com/company/careers",
            "4 days ago"
        ),
        (
            6,
            "Data Analytics & Business Operations Intern [DEMO DATA]",
            "Data Analytics",
            "Bengaluru, Karnataka",
            "Virtual / Remote",
            "2 Months",
            14000,
            "₹14,000 / month",
            1, 0,
            "College students proficient in MS Excel, basic SQL, and analytical reasoning",
            "Stipend, Certificate of Excellence, Pre-Placement Consideration",
            "Analyze logistics metrics, customer rating cohorts, and turnaround benchmarks.",
            0,
            "Demo",
            "DEMO DATA: Illustrative zero-fee internship curriculum model. Not an active corporate vacancy. For live opportunities, visit the official career portal source link.",
            "https://careers.swiggy.com",
            "2026-10-20",
            1,
            "https://careers.swiggy.com",
            "3 days ago"
        ),
        (
            7,
            "Community & Content Strategy Intern [DEMO DATA]",
            "Digital Marketing",
            "Gurugram, Haryana",
            "In-Office",
            "3 Months",
            12000,
            "₹12,000 / month",
            1, 0,
            "College students with creative writing skills and active social media presence",
            "Stipend, Certificate, Live campaign management experience",
            "Create engaging social media narratives, student campus outreach, and creative micro-copy.",
            0,
            "Demo",
            "DEMO DATA: Illustrative zero-fee internship curriculum model. Not an active corporate vacancy. For live opportunities, visit the official career portal source link.",
            "https://www.zomato.com/careers",
            "2026-10-20",
            1,
            "https://www.zomato.com/careers",
            "5 days ago"
        )
    ]

    cur.executemany("""
        INSERT INTO internships (
            company_id, title, domain, location, work_mode, duration,
            stipend_amount, stipend_display, is_paid, requires_fee,
            eligibility, perks, description, safety_verified,
            verification_status, verification_notes, source_url,
            last_checked_date, is_demo, official_apply_url, posted_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, internships_data)

    # Demo Notifications
    notifications_data = [
        (
            "SCAM ALERT: Telegram 'Daily Task' Work-from-Home Fraud",
            "SCAM ALERT",
            "Indian students are being targeted with unsolicited messages offering ₹2,000 to ₹5,000 daily for liking YouTube videos or writing Google reviews. Victims are lured into Telegram groups and asked to deposit money into recharge wallets. Never send money to receive tasks.",
            "danger",
            "Today at 10:30 AM",
            0
        ),
        (
            "SAFETY ADVISORY: Fake Laptop Security Deposit Scheme",
            "SAFETY TIP",
            "Fraudulent networks are emailing fake appointment letters claiming to be TCS or Infosys, demanding ₹3,500 - ₹5,000 as refundable courier or laptop security deposit. Official IT corporations NEVER charge candidates for company assets.",
            "warning",
            "Yesterday",
            0
        ),
        (
            "CAMPUS UPDATE: Unpaid Internships Demanding 'Certificate Fees'",
            "CAMPUS UPDATE",
            "Beware of companies offering unpaid internships that require an upfront 'registration fee' or 'training certification charge' of ₹1,000 - ₹3,000. Under Indian UGC and AICTE internship norms, genuine internships should not charge students.",
            "info",
            "2 days ago",
            0
        ),
        (
            "SECURITY TIP: Verify Domain Extensions",
            "SAFETY TIP",
            "Always inspect the sender's email address. Scammers frequently register lookalike domains like 'company-careers.xyz' or 'tcs-recruitment.in'. Real corporate emails come from canonical domains like @tcs.com, @infosys.com, or @wipro.com.",
            "info",
            "3 days ago",
            1
        )
    ]

    cur.executemany("""
        INSERT INTO notifications (
            title, category, message, severity, date_posted, is_read
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, notifications_data)

    # Initial Offer Scans
    scans_data = [
        (
            "Tata Consultancy Services (Demo Case)",
            "Junior Associate",
            "tcs.hr.recruitment2026@gmail.com",
            "₹6.5 LPA",
            "Laptop Security Deposit",
            4500,
            95,
            "CRITICAL",
            "CRITICAL RISK: High Probability Scam Pattern",
            "Demands ₹4,500 refundable laptop courier deposit sent via personal UPI. Recruiter used Gmail address.",
            "2026-10-18 14:22:10"
        ),
        (
            "Global Task Media (Demo Case)",
            "Part-time Review Associate",
            "hr@mediatask-online.xyz",
            "₹3,000/day",
            "Registration Fee",
            1200,
            88,
            "CRITICAL",
            "CRITICAL RISK: High Probability Scam Pattern",
            "Telegram recruitment offering unrealistic daily pay for video likes, requiring ₹1,200 wallet activation fee.",
            "2026-10-19 09:15:40"
        ),
        (
            "Tata Consultancy Services (Verified Demo)",
            "System Engineer Trainee",
            "campus.recruitment@tcs.com",
            "₹3.6 LPA",
            "None",
            0,
            8,
            "LOW",
            "LOW RISK: Consistent with Genuine Recruitment",
            "Official corporate domain, multi-round interview process, zero fee requested.",
            "2026-10-19 16:45:00"
        )
    ]

    cur.executemany("""
        INSERT INTO offer_scans (
            company_name, job_title, recruiter_email, salary_offered,
            fee_demanded_type, fee_amount, risk_score, risk_level,
            verdict_title, verdict_summary, scanned_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, scans_data)

    # Initial Saved Items
    cur.execute("INSERT OR IGNORE INTO saved_items (item_type, item_id) VALUES ('job', 1)")
    cur.execute("INSERT OR IGNORE INTO saved_items (item_type, item_id) VALUES ('internship', 1)")

    conn.commit()


# -------------------------------------------------------------------
# Database Query Helpers
# -------------------------------------------------------------------

def get_companies(query: str = "", industry: str = "", status: str = "", db_path: str = "careersafe.db") -> List[Dict[str, Any]]:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    sql = "SELECT * FROM companies WHERE 1=1"
    params = []
    
    if query:
        sql += " AND (name LIKE ? OR slug LIKE ? OR headquarters LIKE ? OR description LIKE ? OR legitimate_domains LIKE ?)"
        wildcard = f"%{query}%"
        params.extend([wildcard, wildcard, wildcard, wildcard, wildcard])
        
    if industry:
        sql += " AND industry LIKE ?"
        params.append(f"%{industry}%")

    if status:
        sql += " AND verification_status = ?"
        params.append(status)
        
    sql += " ORDER BY trust_score DESC, name ASC"
    cur.execute(sql, params)
    rows = cur.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_company_by_slug(slug: str, db_path: str = "careersafe.db") -> Optional[Dict[str, Any]]:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    cur.execute("SELECT * FROM companies WHERE slug = ?", (slug,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return None
    company = dict(row)
    
    cur.execute("SELECT * FROM jobs WHERE company_id = ?", (company["id"],))
    company["jobs"] = [dict(r) for r in cur.fetchall()]
    
    cur.execute("SELECT * FROM internships WHERE company_id = ?", (company["id"],))
    company["internships"] = [dict(r) for r in cur.fetchall()]
    
    conn.close()
    return company


def get_jobs(
    query: str = "",
    domain: str = "",
    location: str = "",
    work_mode: str = "",
    experience: str = "",
    status: str = "",
    db_path: str = "careersafe.db"
) -> List[Dict[str, Any]]:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    sql = """
        SELECT j.*, c.name as company_name, c.slug as company_slug, c.trust_score, c.official_website
        FROM jobs j
        JOIN companies c ON j.company_id = c.id
        WHERE 1=1
    """
    params = []
    
    if query:
        sql += " AND (j.title LIKE ? OR j.description LIKE ? OR c.name LIKE ?)"
        wildcard = f"%{query}%"
        params.extend([wildcard, wildcard, wildcard])
        
    if domain:
        sql += " AND j.domain LIKE ?"
        params.append(f"%{domain}%")
        
    if location:
        sql += " AND j.location LIKE ?"
        params.append(f"%{location}%")
        
    if work_mode:
        sql += " AND j.work_mode LIKE ?"
        params.append(f"%{work_mode}%")

    if experience:
        sql += " AND j.experience_level LIKE ?"
        params.append(f"%{experience}%")

    if status:
        sql += " AND j.verification_status = ?"
        params.append(status)
        
    sql += " ORDER BY j.id DESC"
    cur.execute(sql, params)
    rows = cur.fetchall()
    
    cur.execute("SELECT item_id FROM saved_items WHERE item_type = 'job'")
    saved_ids = {r[0] for r in cur.fetchall()}
    
    conn.close()
    
    results = []
    for row in rows:
        item = dict(row)
        item["is_saved"] = item["id"] in saved_ids
        results.append(item)
    return results


def get_job_by_id(job_id: int, db_path: str = "careersafe.db") -> Optional[Dict[str, Any]]:
    """Retrieves a single job with full company details and verification audit information."""
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    sql = """
        SELECT j.*, c.name as company_name, c.slug as company_slug, c.trust_score,
               c.official_website, c.official_career_portal, c.legitimate_domains,
               c.recruitment_policy, c.known_scam_tactics
        FROM jobs j
        JOIN companies c ON j.company_id = c.id
        WHERE j.id = ?
    """
    cur.execute(sql, (job_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return None
    item = dict(row)

    cur.execute("SELECT id FROM saved_items WHERE item_type = 'job' AND item_id = ?", (job_id,))
    item["is_saved"] = cur.fetchone() is not None
    conn.close()
    return item


def get_internships(
    query: str = "",
    domain: str = "",
    location: str = "",
    work_mode: str = "",
    duration: str = "",
    stipend_filter: str = "",
    status: str = "",
    db_path: str = "careersafe.db"
) -> List[Dict[str, Any]]:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    sql = """
        SELECT i.*, c.name as company_name, c.slug as company_slug, c.trust_score, c.official_website
        FROM internships i
        JOIN companies c ON i.company_id = c.id
        WHERE 1=1
    """
    params = []
    
    if query:
        sql += " AND (i.title LIKE ? OR i.description LIKE ? OR c.name LIKE ?)"
        wildcard = f"%{query}%"
        params.extend([wildcard, wildcard, wildcard])
        
    if domain:
        sql += " AND i.domain LIKE ?"
        params.append(f"%{domain}%")
        
    if location:
        sql += " AND i.location LIKE ?"
        params.append(f"%{location}%")
        
    if work_mode:
        sql += " AND i.work_mode LIKE ?"
        params.append(f"%{work_mode}%")

    if duration:
        sql += " AND i.duration LIKE ?"
        params.append(f"%{duration}%")

    if stipend_filter == "paid":
        sql += " AND i.is_paid = 1 AND i.stipend_amount > 0"
    elif stipend_filter == "gt15k":
        sql += " AND i.stipend_amount >= 15000"
    elif stipend_filter == "gt20k":
        sql += " AND i.stipend_amount >= 20000"

    if status:
        sql += " AND i.verification_status = ?"
        params.append(status)
        
    sql += " ORDER BY i.id DESC"
    cur.execute(sql, params)
    rows = cur.fetchall()
    
    cur.execute("SELECT item_id FROM saved_items WHERE item_type = 'internship'")
    saved_ids = {r[0] for r in cur.fetchall()}
    
    conn.close()
    
    results = []
    for row in rows:
        item = dict(row)
        item["is_saved"] = item["id"] in saved_ids
        results.append(item)
    return results


def get_internship_by_id(internship_id: int, db_path: str = "careersafe.db") -> Optional[Dict[str, Any]]:
    """Retrieves a single internship with full company details and verification audit information."""
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    sql = """
        SELECT i.*, c.name as company_name, c.slug as company_slug, c.trust_score,
               c.official_website, c.official_career_portal, c.legitimate_domains,
               c.recruitment_policy, c.known_scam_tactics
        FROM internships i
        JOIN companies c ON i.company_id = c.id
        WHERE i.id = ?
    """
    cur.execute(sql, (internship_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return None
    item = dict(row)

    cur.execute("SELECT id FROM saved_items WHERE item_type = 'internship' AND item_id = ?", (internship_id,))
    item["is_saved"] = cur.fetchone() is not None
    conn.close()
    return item


def toggle_save_item(item_type: str, item_id: int, db_path: str = "careersafe.db") -> bool:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    cur.execute("SELECT id FROM saved_items WHERE item_type = ? AND item_id = ?", (item_type, item_id))
    existing = cur.fetchone()
    
    if existing:
        cur.execute("DELETE FROM saved_items WHERE item_type = ? AND item_id = ?", (item_type, item_id))
        conn.commit()
        conn.close()
        return False
    else:
        cur.execute("INSERT INTO saved_items (item_type, item_id) VALUES (?, ?)", (item_type, item_id))
        conn.commit()
        conn.close()
        return True


def get_user_dashboard_data(db_path: str = "careersafe.db") -> Dict[str, Any]:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    
    cur.execute("""
        SELECT j.*, c.name as company_name, c.slug as company_slug, s.saved_at
        FROM saved_items s
        JOIN jobs j ON s.item_id = j.id
        JOIN companies c ON j.company_id = c.id
        WHERE s.item_type = 'job'
        ORDER BY s.saved_at DESC
    """)
    saved_jobs = [dict(r) for r in cur.fetchall()]
    
    cur.execute("""
        SELECT i.*, c.name as company_name, c.slug as company_slug, s.saved_at
        FROM saved_items s
        JOIN internships i ON s.item_id = i.id
        JOIN companies c ON i.company_id = c.id
        WHERE s.item_type = 'internship'
        ORDER BY s.saved_at DESC
    """)
    saved_internships = [dict(r) for r in cur.fetchall()]
    
    cur.execute("SELECT * FROM offer_scans ORDER BY id DESC LIMIT 20")
    scans = [dict(r) for r in cur.fetchall()]
    
    cur.execute("SELECT * FROM notifications ORDER BY id DESC")
    notifications = [dict(r) for r in cur.fetchall()]
    
    unread_notifications_count = sum(1 for n in notifications if not n["is_read"])
    
    conn.close()
    
    return {
        "saved_jobs": saved_jobs,
        "saved_internships": saved_internships,
        "scans": scans,
        "notifications": notifications,
        "unread_notifications_count": unread_notifications_count
    }


def record_scan_result(scan_data: Dict[str, Any], db_path: str = "careersafe.db") -> int:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO offer_scans (
            company_name, job_title, recruiter_email, salary_offered,
            fee_demanded_type, fee_amount, risk_score, risk_level,
            verdict_title, verdict_summary, scanned_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        scan_data.get("company_name", "Unknown"),
        scan_data.get("job_title", "Unknown"),
        scan_data.get("recruiter_email", ""),
        scan_data.get("salary_offered", ""),
        scan_data.get("fee_demanded_type", "None"),
        scan_data.get("fee_amount", 0),
        scan_data.get("risk_score", 0),
        scan_data.get("risk_level", "LOW"),
        scan_data.get("verdict_title", ""),
        scan_data.get("verdict_summary", ""),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    scan_id = cur.lastrowid
    conn.commit()
    conn.close()
    return scan_id


def mark_notification_as_read(notif_id: int, db_path: str = "careersafe.db") -> bool:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    cur.execute("UPDATE notifications SET is_read = 1 WHERE id = ?", (notif_id,))
    conn.commit()
    conn.close()
    return True


def mark_all_notifications_as_read(db_path: str = "careersafe.db") -> bool:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    cur.execute("UPDATE notifications SET is_read = 1")
    conn.commit()
    conn.close()
    return True


def record_scam_report(report_data: Dict[str, Any], db_path: str = "careersafe.db") -> int:
    conn = get_db_connection(db_path)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO scam_reports (
            scammer_name, company_impersonated, contact_method,
            email_or_phone, amount_demanded, details, reported_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        report_data.get("scammer_name", ""),
        report_data.get("company_impersonated", ""),
        report_data.get("contact_method", ""),
        report_data.get("email_or_phone", ""),
        report_data.get("amount_demanded", ""),
        report_data.get("details", ""),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    report_id = cur.lastrowid
    conn.commit()
    conn.close()
    return report_id
