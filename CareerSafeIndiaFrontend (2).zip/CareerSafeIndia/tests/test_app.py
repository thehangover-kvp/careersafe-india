"""
CareerSafe India - Automated Test Suite
Tests the detection engine, database operations, and Flask web routes.
"""
import unittest
import os
import sys
import tempfile
import json

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import app
import database as db
import checker

class CareerSafeTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Create temporary database for testing
        cls.db_fd, cls.test_db_path = tempfile.mkstemp(suffix=".db")
        app.config["TESTING"] = True
        app.config["DATABASE_PATH"] = cls.test_db_path
        app.config["WTF_CSRF_ENABLED"] = False
        cls.client = app.test_client()

        # Initialize and seed test database
        db.init_db(cls.test_db_path)

    @classmethod
    def tearDownClass(cls):
        os.close(cls.db_fd)
        if os.path.exists(cls.test_db_path):
            os.remove(cls.test_db_path)

    # ----------------------------------------------------
    # 1. Detection Engine Unit Tests
    # ----------------------------------------------------

    def test_laptop_deposit_scam_detection(self):
        """Test that asking for laptop courier/security deposit flags critical risk."""
        payload = {
            "company_name": "Tata Consultancy Services (Demo Case)",
            "job_title": "Software Engineer",
            "recruiter_email": "tcs.hr.recruitment@gmail.com",
            "contact_mode": "Unsolicited WhatsApp Direct Message",
            "interview_process": "Direct offer letter without interview",
            "salary_offered": "₹6.5 LPA",
            "fee_demanded_type": "Laptop Security Deposit & Courier Fee",
            "fee_amount": 4500,
            "offer_text": "Pay refundable ₹4,500 for laptop courier via GPay within 24 hours."
        }
        result = checker.analyze_offer(payload)
        self.assertEqual(result["risk_level"], "CRITICAL")
        self.assertGreaterEqual(result["score"], 75)
        # Check that critical red flag exists
        red_flag_titles = [f["title"] for f in result["red_flags"]]
        self.assertTrue(any("Payment Requested" in t for t in red_flag_titles))
        self.assertTrue(any("Impersonation" in t for t in red_flag_titles))
        # Ensure mandatory disclaimer is present
        self.assertIn("educational and initial screening advisory tool", result["disclaimer"])
        self.assertIn("NOT a guaranteed fraud detector", result["disclaimer"])

    def test_telegram_task_scam_detection(self):
        """Test that Telegram video liking task scams are detected as critical risk."""
        payload = {
            "company_name": "Task Media Online",
            "job_title": "YouTube Review Associate",
            "recruiter_email": "hr@mediatask.xyz",
            "contact_mode": "Telegram Channel / Direct Message",
            "interview_process": "Short 5-minute chat on WhatsApp/Telegram",
            "salary_offered": "₹3,000 per day",
            "fee_demanded_type": "Registration Fee",
            "fee_amount": 1000,
            "offer_text": "Earn ₹3000 daily by liking YouTube videos. Pay ₹1000 registration fee to activate wallet."
        }
        result = checker.analyze_offer(payload)
        self.assertEqual(result["risk_level"], "CRITICAL")
        red_flag_titles = [f["title"] for f in result["red_flags"]]
        self.assertTrue(any("Telegram" in t for t in red_flag_titles))

    def test_legitimate_campus_offer_detection(self):
        """Test that a legitimate campus offer with corporate domain receives a low risk score."""
        payload = {
            "company_name": "Tata Consultancy Services",
            "job_title": "System Engineer Trainee",
            "recruiter_email": "campus.recruitment@tcs.com",
            "contact_mode": "Official Job Portal / Campus Drive",
            "interview_process": "Multi-round (Technical + HR Interviews)",
            "salary_offered": "₹3.6 LPA",
            "fee_demanded_type": "None",
            "fee_amount": 0,
            "offer_text": "TCS does not charge any fee at any stage. You are offered employment with PF and medical benefits."
        }
        result = checker.analyze_offer(payload)
        self.assertEqual(result["risk_level"], "LOW")
        self.assertLessEqual(result["score"], 25)
        self.assertGreater(len(result["green_flags"]), 0)

    def test_presets_availability(self):
        """Test that sample presets exist and contain required data."""
        presets = checker.get_demo_presets()
        self.assertGreaterEqual(len(presets), 3)
        for p in presets:
            self.assertIn("id", p)
            self.assertIn("label", p)
            self.assertIn("data", p)

    # ----------------------------------------------------
    # 2. Database Operation Tests
    # ----------------------------------------------------

    def test_database_companies_and_search(self):
        companies = db.get_companies(db_path=self.test_db_path)
        self.assertGreater(len(companies), 0)

        # Search query
        filtered = db.get_companies(query="TCS", db_path=self.test_db_path)
        self.assertGreaterEqual(len(filtered), 1)

    def test_database_jobs_and_filter(self):
        jobs = db.get_jobs(db_path=self.test_db_path)
        self.assertGreater(len(jobs), 0)

        # Check domain filter
        sw_jobs = db.get_jobs(domain="Software", db_path=self.test_db_path)
        self.assertGreaterEqual(len(sw_jobs), 1)

    def test_database_internships_and_filter(self):
        internships = db.get_internships(db_path=self.test_db_path)
        self.assertGreater(len(internships), 0)

        # Check paid filter
        paid_interns = db.get_internships(stipend_filter="paid", db_path=self.test_db_path)
        self.assertGreaterEqual(len(paid_interns), 1)

    def test_database_save_and_unsave_item(self):
        # Save job 2
        is_saved = db.toggle_save_item("job", 2, db_path=self.test_db_path)
        self.assertTrue(is_saved)

        # Toggle again should remove
        is_saved_again = db.toggle_save_item("job", 2, db_path=self.test_db_path)
        self.assertFalse(is_saved_again)

    # ----------------------------------------------------
    # 3. Flask Route & Web Interface Tests
    # ----------------------------------------------------

    def test_home_page(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"CareerSafe", response.data)
        self.assertIn(b"DEMO MODE", response.data)
        self.assertIn(b"Instant Scam Check Preview", response.data)

    def test_companies_page(self):
        response = self.client.get("/companies")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Company Safety Directory", response.data)
        self.assertIn(b"Tata Consultancy Services", response.data)

    def test_company_detail_page(self):
        response = self.client.get("/companies/tata-consultancy-services")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Official Recruitment Policy", response.data)
        self.assertIn(b"tcs.com", response.data)

    def test_jobs_page(self):
        response = self.client.get("/jobs")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Job Finder", response.data)
        self.assertIn(b"Zero Joining or Registration Fee Required", response.data)

    def test_internships_page(self):
        response = self.client.get("/internships")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Student Internship Finder", response.data)
        self.assertIn(b"Beware of", response.data)

    def test_checker_page_get(self):
        response = self.client.get("/checker")
        self.assertEqual(response.status_code, 200)
        html_text = response.data.decode("utf-8")
        self.assertIn("Fake Offer & Scam Detection Shield", html_text)
        self.assertIn("Instant Sample Scenarios", html_text)

    def test_checker_page_post_form(self):
        response = self.client.post("/checker", data={
            "company_name": "Tata Consultancy Services (Demo)",
            "job_title": "Fresher Developer",
            "recruiter_email": "tcs.recruitment@gmail.com",
            "contact_mode": "Unsolicited WhatsApp Direct Message",
            "interview_process": "Direct offer letter without interview",
            "salary_offered": "₹6 LPA",
            "fee_demanded_type": "Laptop Security Deposit & Courier Fee",
            "fee_amount": "4000",
            "offer_text": "Pay ₹4000 laptop deposit."
        })
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"CRITICAL RISK", response.data)
        self.assertIn(b"Red Flags Detected", response.data)
        self.assertIn(b"Educational Screening Notice", response.data)

    def test_api_check_offer(self):
        payload = {
            "company_name": "Infosys (Demo)",
            "job_title": "Systems Engineer",
            "recruiter_email": "hr@infosys.com",
            "contact_mode": "Official Job Portal / Campus Drive",
            "interview_process": "Multi-round (Technical + HR Interviews)",
            "salary_offered": "₹4 LPA",
            "fee_demanded_type": "None",
            "fee_amount": 0,
            "offer_text": "Official appointment offer."
        }
        response = self.client.post(
            "/api/check-offer",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn("score", data)
        self.assertIn("risk_level", data)
        self.assertIn("disclaimer", data)
        self.assertEqual(data["risk_level"], "LOW")

    def test_dashboard_page(self):
        response = self.client.get("/dashboard")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Student Career Dashboard", response.data)
        self.assertIn(b"Saved Jobs", response.data)
        self.assertIn(b"Scan History", response.data)

    def test_report_scam_flow(self):
        # GET report form
        get_res = self.client.get("/report-scam")
        self.assertEqual(get_res.status_code, 200)
        self.assertIn(b"Report a Suspicious Recruiter", get_res.data)

        # POST report
        post_res = self.client.post("/report-scam", data={
            "company_impersonated": "Demo Fake Corp",
            "scammer_name": "Priya Sharma",
            "contact_method": "Telegram",
            "email_or_phone": "+91 9999988888",
            "amount_demanded": "₹2,500",
            "details": "Offered part time typing job and asked for registration fee via UPI."
        }, follow_redirects=True)
        self.assertEqual(post_res.status_code, 200)
        self.assertIn(b"Your fraud report has been submitted", post_res.data)

    def test_safety_guide_page(self):
        response = self.client.get("/about-safety")
        self.assertEqual(response.status_code, 200)
        html_text = response.data.decode("utf-8")
        self.assertIn("Indian Job & Internship Safety Manual", html_text)
        self.assertIn("Laptop Courier / Security Deposit", html_text)
        self.assertIn("1930", html_text)

    # ----------------------------------------------------
    # 4. Verification Auditing & Honesty Tests
    # ----------------------------------------------------

    def test_verification_fields_schema(self):
        """Verifies that source_url, last_checked_date, verification_status, and notes exist in DB."""
        conn = db.get_db_connection(self.test_db_path)
        cur = conn.cursor()

        cur.execute("PRAGMA table_info(companies)")
        comp_cols = {r[1] for r in cur.fetchall()}
        self.assertTrue({"source_url", "last_checked_date", "verification_status", "verification_notes"}.issubset(comp_cols))

        cur.execute("PRAGMA table_info(jobs)")
        job_cols = {r[1] for r in cur.fetchall()}
        self.assertTrue({"source_url", "last_checked_date", "verification_status", "verification_notes"}.issubset(job_cols))

        cur.execute("PRAGMA table_info(internships)")
        intern_cols = {r[1] for r in cur.fetchall()}
        self.assertTrue({"source_url", "last_checked_date", "verification_status", "verification_notes"}.issubset(intern_cols))
        conn.close()

    def test_demo_records_honesty(self):
        """Verifies that no sample/demo listing is falsely claimed as 'Verified'."""
        conn = db.get_db_connection(self.test_db_path)
        cur = conn.cursor()

        # Jobs: all demo jobs must have status 'Demo' and safety_verified == 0
        cur.execute("SELECT id, title, verification_status, safety_verified, source_url, verification_notes FROM jobs WHERE is_demo = 1")
        jobs = cur.fetchall()
        for j in jobs:
            self.assertEqual(j["verification_status"], "Demo", f"Job {j['title']} should have Demo status")
            self.assertEqual(j["safety_verified"], 0, f"Job {j['title']} should not be marked safety_verified=1")
            self.assertTrue(len(j["source_url"]) > 0, f"Job {j['title']} should have an official source url")
            self.assertIn("DEMO DATA", j["verification_notes"])

        # Internships: all demo internships must have status 'Demo' and safety_verified == 0
        cur.execute("SELECT id, title, verification_status, safety_verified, source_url, verification_notes FROM internships WHERE is_demo = 1")
        interns = cur.fetchall()
        for i in interns:
            self.assertEqual(i["verification_status"], "Demo", f"Internship {i['title']} should have Demo status")
            self.assertEqual(i["safety_verified"], 0)
            self.assertTrue(len(i["source_url"]) > 0)
            self.assertIn("DEMO DATA", i["verification_notes"])

        # Simulated scam case study must be 'Unable to Verify'
        cur.execute("SELECT verification_status, verification_notes FROM companies WHERE id = 8")
        apex = cur.fetchone()
        self.assertEqual(apex["verification_status"], "Unable to Verify")
        conn.close()

    def test_company_detail_verification_audit(self):
        """Tests that the company detail page renders the Verification & Source Audit panel."""
        response = self.client.get("/companies/tata-consultancy-services")
        self.assertEqual(response.status_code, 200)
        html = response.data.decode("utf-8")
        self.assertIn("Verification &amp; Source Audit", html)
        self.assertIn("Official Source Link", html)
        self.assertIn("Last Checked Date", html)
        self.assertIn("Official Source Linked", html)

    def test_job_detail_page(self):
        """Tests that the job detail page renders source link and verification explanation."""
        response = self.client.get("/jobs/1")
        self.assertEqual(response.status_code, 200)
        html = response.data.decode("utf-8")
        self.assertIn("Listing Verification &amp; Source Audit", html)
        self.assertIn("Verification Explanation", html)
        self.assertIn("DEMO DATA", html)
        self.assertIn("Official Source Link", html)
        self.assertIn("tcs.com/careers/india", html)

    def test_internship_detail_page(self):
        """Tests that the internship detail page renders source link and verification explanation."""
        response = self.client.get("/internships/1")
        self.assertEqual(response.status_code, 200)
        html = response.data.decode("utf-8")
        self.assertIn("Internship Verification &amp; Source Audit", html)
        self.assertIn("Verification Explanation", html)
        self.assertIn("DEMO DATA", html)
        self.assertIn("Zero-Fee Rule", html)
        self.assertIn("Official Source Link", html)

    def test_jobs_status_filter(self):
        """Tests filtering jobs by verification status."""
        response = self.client.get("/jobs?status=Demo")
        self.assertEqual(response.status_code, 200)
        html = response.data.decode("utf-8")
        self.assertIn("Graduate Trainee Engineer", html)

        # Filtering for non-existent status returns no jobs message
        empty_response = self.client.get("/jobs?status=Expired")
        self.assertEqual(empty_response.status_code, 200)
        self.assertIn("No jobs match your filter criteria", empty_response.data.decode("utf-8"))

    def test_internships_status_filter(self):
        """Tests filtering internships by verification status."""
        response = self.client.get("/internships?status=Demo")
        self.assertEqual(response.status_code, 200)
        html = response.data.decode("utf-8")
        self.assertIn("Python Backend Development Intern", html)

if __name__ == "__main__":
    unittest.main()
