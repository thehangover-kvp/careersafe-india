
document.addEventListener("DOMContentLoaded", () => {
  console.log("CareerSafe India frontend loaded!");

  // Backend connection test
  fetch("http://127.0.0.1:5000/api/health")
    .then(response => {
      if (!response.ok) {
        throw new Error("Backend health check failed");
      }
      return response.json();
    })
    .then(data => {
      console.log("Backend connected:", data.message);
    })
    .catch(error => {
      console.error("Backend connection error:", error);
    });

  // Fake job offer detection
  window.checkOfferWithBackend = async function (offerText) {
    try {
      const response = await fetch(
        "http://127.0.0.1:5000/api/check-offer",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            offer_text: offerText
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Analysis failed");
      }

      return data;
    } catch (error) {
      console.error("Offer analysis error:", error);
      alert("Offer analysis failed. Backend running-ah nu check pannu.");
      return null;
    }
  };
});

async function loadCompanies() {
  const container = document.getElementById("companiesList");

  if (!container) return;

  container.innerHTML = "<p>Loading companies...</p>";

  try {
    const response = await fetch(
      "http://127.0.0.1:5000/api/companies"
    );

    if (!response.ok) {
      throw new Error("Failed to load companies");
    }

    const companies = await response.json();

    if (!companies.length) {
      container.innerHTML = "<p>No companies found.</p>";
      return;
    }

    container.innerHTML = companies.map(company => `
      <article class="card">
        <h3>${escapeCompanyText(company.name)}</h3>
        <p><strong>Industry:</strong> ${escapeCompanyText(company.industry || "Not available")}</p>
        <p><strong>Status:</strong> ${escapeCompanyText(company.verification_status || "Unverified")}</p>
        <a href="${getOfficialCompanyWebsite(company.website)}"
           target="_blank"
           rel="noopener noreferrer">
          Visit Official Website ↗
        </a>
      </article>
    `).join("");
  } catch (error) {
    console.error("Companies loading error:", error);
    container.innerHTML =
      "<p>Unable to load companies. Please check whether the backend is running.</p>";
  }
}

function escapeCompanyText(value) {
  const element = document.createElement("span");
  element.textContent = String(value);
  return element.innerHTML;
}

function getOfficialCompanyWebsite(value) {
  try {
    const url = new URL(value);

    if (
      url.protocol === "https:" &&
      ["infosys.com", "tcs.com", "wipro.com"].some(
        domain =>
          url.hostname === domain ||
          url.hostname.endsWith("." + domain)
      )
    ) {
      return url.href;
    }
  } catch (error) {
    console.warn("Invalid company website URL");
  }

  return "#companies-list";
}

document.addEventListener("DOMContentLoaded", loadCompanies);

async function loadOpportunities() {
  const container = document.getElementById("opportunitiesList");

  if (!container) return;

  container.innerHTML = "<p>Loading opportunities...</p>";

  try {
    const response = await fetch(
      "http://127.0.0.1:5000/api/opportunities"
    );

    if (!response.ok) {
      throw new Error("Failed to load opportunities");
    }

    const opportunities = await response.json();

    if (!opportunities.length) {
      container.innerHTML = "<p>No opportunities available.</p>";
      return;
    }

    container.innerHTML = opportunities.map(job => {
      let safeUrl = "#job-opportunities";

      try {
        const url = new URL(job.source_url);

        const allowedDomains = [
          "tcs.com",
          "infosys.com",
          "wipro.com"
        ];

        if (
          url.protocol === "https:" &&
          allowedDomains.some(domain =>
            url.hostname === domain ||
            url.hostname.endsWith("." + domain)
          )
        ) {
          safeUrl = url.href;
        }
      } catch (error) {
        console.warn("Invalid opportunity source URL");
      }

      return `
        <article class="card">
          <h3>${escapeCompanyText(job.title)}</h3>

          <p><strong>Company:</strong>
            ${escapeCompanyText(job.company_name)}
          </p>

          <p><strong>Type:</strong>
            ${escapeCompanyText(job.opportunity_type)}
          </p>

          <p><strong>Location:</strong>
            ${escapeCompanyText(job.location)}
          </p>

          <p><strong>Salary / Stipend:</strong>
            ${escapeCompanyText(job.salary_or_stipend)}
          </p>

          <p><strong>Deadline:</strong>
            ${escapeCompanyText(job.deadline)}
          </p>

          <p><strong>Status:</strong>
            ${escapeCompanyText(job.verification_status)}
          </p>

          <a href="${safeUrl}"
             target="_blank"
             rel="noopener noreferrer">
            Visit Official Careers Page ↗
          </a>
        </article>
      `;
    }).join("");

  } catch (error) {
    console.error("Opportunities loading error:", error);

    container.innerHTML =
      "<p>Unable to load opportunities. Please check the backend.</p>";
  }
}

document.addEventListener("DOMContentLoaded", loadOpportunities);

async function verifyOfficialJob() {
  console.log("Verify Job button clicked!");
  const jobId = document.getElementById("verifyJobId").value.trim();
  const jobTitle = document.getElementById("verifyJobTitle").value.trim();
  const company = document.getElementById("verifyCompany").value;
  const resultBox = document.getElementById("jobVerificationResult");

  if (!jobId || !jobTitle) {
    resultBox.textContent = "Please enter both Job ID and Job Title.";
    return;
  }

  if (!/^\d+$/.test(jobId)) {
    resultBox.textContent = "Job ID must contain numbers only.";
    return;
  }

  resultBox.textContent = `Checking ${company}'s official careers source...`;

  try {
    const response = await fetch(
      "http://127.0.0.1:5000/api/verify-job",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
  company: company,
  job_id: jobId,
  job_title: jobTitle
})
      }
    );

    const data = await response.json();

    resultBox.replaceChildren();

    const heading = document.createElement("h3");
    heading.textContent =
      data.status === "verified"
        ? "✅ Job Listing Matched"
        : "⚠️ Job Not Verified";

    const message = document.createElement("p");
    message.textContent = data.message || "No verification details available.";

    resultBox.append(heading, message);

    if (data.official_url) {
  const link = document.createElement("a");

  link.href = data.official_url;
  link.target = "_blank";
  link.rel = "noopener noreferrer";

  link.textContent =
    data.status === "verified"
      ? `Open Official ${data.company || company} Job ↗`
      : `Open Official ${data.company || company} Careers ↗`;

  resultBox.appendChild(link);
}

    if (!response.ok) {
      console.warn("Job verification returned HTTP", response.status);
    }

  } catch (error) {
    console.error("Job verification error:", error);
    resultBox.textContent =
      "Unable to contact the backend. Check whether Flask is running.";
  }
}
